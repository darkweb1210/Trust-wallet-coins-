import { NextRequest } from "next/server";
import { publicConfig } from "@/config/public-config";
import {
  getShareImageResponse,
  parseNextRequestSearchParams,
} from "@/neynar-farcaster-sdk/nextjs";

// Cache for 1 hour - query strings create separate cache entries
export const revalidate = 3600;

const { appEnv, heroImageUrl, imageUrl, iconUrl } = publicConfig;

const showDevWarning = appEnv !== "production";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ type: string }> },
) {
  const { type } = await params;

  const searchParams = parseNextRequestSearchParams(request);
  const name = searchParams.name ?? null;
  const symbol = searchParams.symbol ?? null;

  return getShareImageResponse(
    { type, heroImageUrl, imageUrl, showDevWarning },
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        height: "100%",
        backgroundColor: "#0a0a1a",
        alignItems: "flex-start",
        justifyContent: "space-between",
        padding: "56px 64px",
      }}
    >
      {/* Top: title block */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <img
            src={iconUrl}
            alt="Trust Wallet"
            width={72}
            height={72}
            style={{
              display: "flex",
              borderRadius: 16,
              backgroundColor: "rgba(255,255,255,0.95)",
              padding: 8,
            }}
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <div
              style={{
                display: "flex",
                fontSize: 56,
                fontWeight: "bold",
                color: "#3375BB",
                letterSpacing: -1,
              }}
            >
              Trust Wallet Token Launch
            </div>
            <div
              style={{
                display: "flex",
                fontSize: 22,
                color: "rgba(0,230,160,0.8)",
                letterSpacing: 2,
                textTransform: "uppercase",
              }}
            >
              Secure BSC launch and liquidity
            </div>
          </div>
        </div>
      </div>

      {/* Bottom: token card or tagline + powered by */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 24,
          width: "100%",
        }}
      >
        {name && symbol ? (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 8,
              backgroundColor: "rgba(51,117,187,0.1)",
              border: "2px solid rgba(0,230,160,0.35)",
              borderRadius: 20,
              padding: "28px 36px",
            }}
          >
            <div
              style={{
                display: "flex",
                fontSize: 20,
                color: "rgba(255,255,255,0.68)",
                textTransform: "uppercase",
                letterSpacing: 2,
              }}
            >
              Live token launch
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "baseline",
                gap: 16,
              }}
            >
              <div
                style={{
                  display: "flex",
                  fontSize: 52,
                  fontWeight: "bold",
                  color: "#3375BB",
                }}
              >
                {name}
              </div>
              <div
                style={{
                  display: "flex",
                  fontSize: 30,
                  color: "rgba(0,230,160,0.9)",
                  fontWeight: "bold",
                }}
              >
                {symbol}
              </div>
            </div>
          </div>
        ) : (
          <div
            style={{
              display: "flex",
              fontSize: 36,
              color: "rgba(255,255,255,0.9)",
              fontWeight: "bold",
            }}
          >
            Launch your BSC token with trusted wallet-grade security.
          </div>
        )}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <div
            style={{
              display: "flex",
              width: 36,
              height: 2,
              backgroundColor: "rgba(51,117,187,0.6)",
            }}
          />
          <div
            style={{
              display: "flex",
              fontSize: 18,
              color: "rgba(51,117,187,0.72)",
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            Powered by Trust Wallet
          </div>
        </div>
      </div>
    </div>,
  );
}
