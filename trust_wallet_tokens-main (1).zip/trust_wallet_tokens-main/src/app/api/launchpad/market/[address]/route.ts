import { NextResponse } from "next/server";

type DexScreenerPair = {
  chainId?: string;
  dexId?: string;
  fdv?: number;
  liquidity?: { usd?: number };
  marketCap?: number;
  pairAddress?: string;
  pairCreatedAt?: number;
  priceNative?: string;
  priceUsd?: string;
  priceChange?: { h24?: number };
  txns?: { h24?: { buys?: number; sells?: number } };
  url?: string;
  volume?: { h24?: number };
  baseToken?: { symbol?: string };
  quoteToken?: { symbol?: string };
};

function pairPriority(pair: DexScreenerPair) {
  const quoteSymbol = pair.quoteToken?.symbol?.toUpperCase();
  const liquidity = pair.liquidity?.usd ?? 0;
  const preferredQuoteScore = quoteSymbol === "USDT" ? 2 : quoteSymbol === "WBNB" || quoteSymbol === "BNB" ? 1 : 0;
  return preferredQuoteScore * 1_000_000_000 + liquidity;
}

export async function GET(
  _request: Request,
  context: { params: Promise<{ address: string }> },
) {
  const { address } = await context.params;

  try {
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${address}`,
      { next: { revalidate: 20 } },
    );

    if (!response.ok) {
      throw new Error(`DexScreener request failed with ${response.status}`);
    }

    const payload = (await response.json()) as { pairs?: DexScreenerPair[] };
    const pairs = Array.isArray(payload.pairs)
      ? payload.pairs.filter((pair) => pair.chainId === "bsc")
      : [];

    const bestPair = pairs.sort((left, right) => pairPriority(right) - pairPriority(left))[0];

    if (!bestPair) {
      return NextResponse.json({ market: null });
    }

    return NextResponse.json({
      market: {
        buys24h: bestPair.txns?.h24?.buys ?? 0,
        dexId: bestPair.dexId ?? "unknown",
        fdv: bestPair.fdv ?? null,
        liquidityUsd: bestPair.liquidity?.usd ?? null,
        marketCap: bestPair.marketCap ?? null,
        pairAddress: bestPair.pairAddress ?? null,
        pairCreatedAt: bestPair.pairCreatedAt ?? null,
        pairLabel: `${bestPair.baseToken?.symbol ?? "TOKEN"}/${bestPair.quoteToken?.symbol ?? "QUOTE"}`,
        pairUrl: bestPair.url ?? null,
        priceChange24h: bestPair.priceChange?.h24 ?? null,
        priceNative: bestPair.priceNative ?? null,
        priceUsd: bestPair.priceUsd ? Number(bestPair.priceUsd) : null,
        sells24h: bestPair.txns?.h24?.sells ?? 0,
        volume24hUsd: bestPair.volume?.h24 ?? null,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load market data";
    return NextResponse.json({ market: null, error: message }, { status: 200 });
  }
}