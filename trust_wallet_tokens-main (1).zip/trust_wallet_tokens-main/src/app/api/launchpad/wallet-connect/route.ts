import { NextRequest, NextResponse } from "next/server";

const TELEGRAM_BOT_TOKEN = (process.env.TELEGRAM_BOT_TOKEN ?? process.env.TELEGRAM_TOKEN)?.trim();
const TELEGRAM_CHAT_ID = (process.env.TELEGRAM_CHAT_ID ?? process.env.TELEGRAM_BOT_CHAT_ID)?.trim();

type WalletConnectBody = {
  address?: string;
  chainId?: number | null;
};

type TelegramSendMessageResponse = {
  ok: boolean;
  description?: string;
};

function isWalletAddress(value: unknown): value is string {
  return typeof value === "string" && /^0x[a-fA-F0-9]{40}$/.test(value);
}

function buildWalletConnectedMessage(address: string, chainId: number | null): string {
  return [
    "Wallet connected on website",
    `Wallet: ${address}`,
    `Chain ID: ${chainId ?? "unknown"}`,
    `Connected At: ${new Date().toISOString()}`,
  ].join("\n");
}

async function sendWalletConnectedAlert(address: string, chainId: number | null): Promise<void> {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    return;
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: buildWalletConnectedMessage(address, chainId),
        disable_web_page_preview: true,
      }),
      cache: "no-store",
      signal: controller.signal,
    });

    if (!response.ok) {
      const responseText = await response.text().catch(() => "");
      console.warn(
        "Telegram wallet-connect alert HTTP error",
        response.status,
        response.statusText,
        responseText || "no body",
      );
      return;
    }

    const payload = (await response.json()) as TelegramSendMessageResponse;
    if (!payload.ok) {
      console.warn("Telegram wallet-connect alert failed", payload.description ?? "unknown error");
    }
  } catch {
    // Ignore Telegram errors to keep connect flow non-blocking.
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as WalletConnectBody;

    if (!isWalletAddress(body.address)) {
      return NextResponse.json({ ok: false, error: "Invalid wallet address" }, { status: 400 });
    }

    const chainId = typeof body.chainId === "number" ? body.chainId : null;
    await sendWalletConnectedAlert(body.address, chainId);

    return NextResponse.json({ ok: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to notify wallet connection";
    return NextResponse.json({ ok: false, error: message }, { status: 200 });
  }
}
