import { NextResponse } from "next/server";
import { createPublicClient, decodeFunctionData, http } from "viem";
import { bsc } from "viem/chains";
import {
  ERC20_METADATA_ABI,
  FLAP_CONTRACTS,
  PORTAL_ABI,
  PORTAL_NEW_TOKEN_SELECTOR,
} from "@/features/launchpad/constants";

const publicClient = createPublicClient({
  chain: bsc,
  transport: http("https://bsc-dataseed.binance.org"),
});

const RECENT_LIMIT = 60;

type BscScanTx = {
  from: string;
  functionName?: string;
  hash: string;
  isError: string;
  methodId?: string;
  timeStamp: string;
  to: string;
};

type LaunchResponse = {
  creator: string;
  imageUrl?: string;
  metaUrl?: string;
  name: string;
  symbol: string;
  timestamp: number;
  tokenAddress: string;
  txHash: string;
};

type TokenMetaPayload = {
  image?: string;
  logo?: string;
  name?: string;
  symbol?: string;
};

function toText(result: unknown, fallback: string) {
  return typeof result === "string" && result.trim() ? result : fallback;
}

function ipfsToHttp(value: string | undefined): string | undefined {
  if (!value) return undefined;
  const trimmed = value.trim();
  if (!trimmed) return undefined;

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  if (/^ipfs:\/\//i.test(trimmed)) {
    const cid = trimmed.replace(/^ipfs:\/\//i, "");
    return `https://ipfs.io/ipfs/${cid}`;
  }

  return `https://ipfs.io/ipfs/${trimmed}`;
}

async function fetchJsonWithTimeout<T>(url: string, timeoutMs: number): Promise<T | null> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      cache: "no-store",
      signal: controller.signal,
    });

    if (!response.ok) {
      return null;
    }

    return (await response.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function fetchRecentPortalTransactions(): Promise<BscScanTx[]> {
  const url = new URL("https://api.bscscan.com/api");
  url.searchParams.set("module", "account");
  url.searchParams.set("action", "txlist");
  url.searchParams.set("address", FLAP_CONTRACTS.PORTAL);
  url.searchParams.set("page", "1");
  url.searchParams.set("offset", String(RECENT_LIMIT * 3));
  url.searchParams.set("sort", "desc");

  const response = await fetch(url.toString(), { next: { revalidate: 30 } });
  if (!response.ok) {
    throw new Error(`BscScan request failed with ${response.status}`);
  }

  const payload = (await response.json()) as { result?: BscScanTx[] };
  if (!Array.isArray(payload.result)) {
    return [];
  }

  return payload.result.filter((tx) => {
    const isLaunchMethod =
      tx.methodId?.toLowerCase() === PORTAL_NEW_TOKEN_SELECTOR ||
      tx.functionName?.includes("newTokenV6");

    return (
      tx.to?.toLowerCase() === FLAP_CONTRACTS.PORTAL.toLowerCase() &&
      tx.isError !== "1" &&
      isLaunchMethod
    );
  });
}

async function resolveLaunch(tx: BscScanTx): Promise<LaunchResponse | null> {
  try {
    const txHash = tx.hash as `0x${string}`;

    const [receipt, chainTx] = await Promise.all([
      publicClient.getTransactionReceipt({ hash: txHash }),
      publicClient.getTransaction({ hash: txHash }),
    ]);

    const tokenAddress = receipt.logs?.[0]?.address;
    if (!tokenAddress || tokenAddress.toLowerCase() === FLAP_CONTRACTS.PORTAL.toLowerCase()) {
      return null;
    }

    let metaCid: string | undefined;
    try {
      const decoded = decodeFunctionData({
        abi: PORTAL_ABI,
        data: chainTx.input,
      });

      const firstArg = decoded.args?.[0] as { meta?: string } | undefined;
      if (firstArg?.meta && typeof firstArg.meta === "string") {
        metaCid = firstArg.meta;
      }
    } catch {
      // Ignore decode failures and continue with contract metadata fallback.
    }

    const metaUrl = ipfsToHttp(metaCid);
    const metadata = metaUrl
      ? await fetchJsonWithTimeout<TokenMetaPayload>(metaUrl, 4000)
      : null;

    const [nameResult, symbolResult] = await publicClient.multicall({
      allowFailure: true,
      contracts: [
        { address: tokenAddress, abi: ERC20_METADATA_ABI, functionName: "name" },
        { address: tokenAddress, abi: ERC20_METADATA_ABI, functionName: "symbol" },
      ],
    });

    const fallbackSymbol = `${tokenAddress.slice(2, 5).toUpperCase()}`;
    const onchainName = toText(nameResult.status === "success" ? nameResult.result : undefined, "New Launch");
    const onchainSymbol = toText(symbolResult.status === "success" ? symbolResult.result : undefined, fallbackSymbol);

    return {
      creator: tx.from,
      imageUrl: ipfsToHttp(metadata?.image ?? metadata?.logo),
      metaUrl,
      name: toText(metadata?.name, onchainName),
      symbol: toText(metadata?.symbol, onchainSymbol),
      timestamp: Number(tx.timeStamp) * 1000,
      tokenAddress,
      txHash: tx.hash,
    };
  } catch {
    return null;
  }
}

export async function GET() {
  try {
    const transactions = await fetchRecentPortalTransactions();
    const launches = (await Promise.all(transactions.slice(0, RECENT_LIMIT).map(resolveLaunch)))
      .filter((launch): launch is LaunchResponse => launch !== null)
      .sort((a, b) => b.timestamp - a.timestamp);

    return NextResponse.json({ launches });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load recent launches";
    return NextResponse.json({ launches: [], error: message }, { status: 200 });
  }
}