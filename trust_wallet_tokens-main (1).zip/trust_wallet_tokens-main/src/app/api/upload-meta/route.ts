import { NextRequest, NextResponse } from "next/server";

// Pinata JWT — hardcoded server-side, never exposed to the browser
const PINATA_JWT =
  process.env.PINATA_JWT ??
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiJjYTBkZmFlYy02NjlmLTQwZGMtODc4ZC05YjFhYzdlNTk4ZmEiLCJlbWFpbCI6ImZiNzM3OTc4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwaW5fcG9saWN5Ijp7InJlZ2lvbnMiOlt7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6IkZSQTEifSx7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6Ik5ZQzEifV0sInZlcnNpb24iOjF9LCJtZmFfZW5hYmxlZCI6ZmFsc2UsInN0YXR1cyI6IkFDVElWRSJ9LCJhdXRoZW50aWNhdGlvblR5cGUiOiJzY29wZWRLZXkiLCJzY29wZWRLZXlLZXkiOiJhNThjMTkzYzljNjFiNTU2ZTcxOSIsInNjb3BlZEtleVNlY3JldCI6ImJlNzgyMDEzNjUwMmMyZDY0MDhiZDJhZDNhYWVlZWE2ZTNiZjgwMjY1N2IzODAwYTNkNmM4NWU1NDFmMjIwZGEiLCJleHAiOjE4MDc1MTA0NjF9.YbaNLj8fBk8yiXrj8TjYVShl3YWLv04GeP_tKx7wyvA";

const PINATA_API = "https://api.pinata.cloud";

async function uploadImageToPinata(
  imageBase64: string,
  imageType: string,
  symbol: string
): Promise<string> {
  const base64Data = imageBase64.replace(/^data:[^,]+,/, "");
  const buffer     = Buffer.from(base64Data, "base64");

  const form = new FormData();
  const blob = new Blob([buffer], { type: imageType });
  const ext  = imageType.split("/")[1] ?? "png";
  form.append("file", blob, `${symbol}.${ext}`);
  form.append("pinataMetadata", JSON.stringify({ name: `${symbol}-image` }));
  form.append("pinataOptions",  JSON.stringify({ cidVersion: 1 }));

  const res = await fetch(`${PINATA_API}/pinning/pinFileToIPFS`, {
    method:  "POST",
    headers: { Authorization: `Bearer ${PINATA_JWT}` },
    body:    form,
  });

  if (!res.ok) {
    throw new Error(`Pinata image upload failed: ${await res.text()}`);
  }

  const data = (await res.json()) as { IpfsHash: string };
  return data.IpfsHash;
}

async function uploadJsonToPinata(
  json: Record<string, unknown>,
  symbol: string
): Promise<string> {
  const res = await fetch(`${PINATA_API}/pinning/pinJSONToIPFS`, {
    method:  "POST",
    headers: {
      Authorization:  `Bearer ${PINATA_JWT}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      pinataContent:  json,
      pinataMetadata: { name: `${symbol}-meta` },
      pinataOptions:  { cidVersion: 1 },
    }),
  });

  if (!res.ok) {
    throw new Error(`Pinata JSON upload failed: ${await res.text()}`);
  }

  const data = (await res.json()) as { IpfsHash: string };
  return data.IpfsHash;
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      name?:        string;
      symbol?:      string;
      description?: string;
      website?:     string;
      twitter?:     string;
      telegram?:    string;
      imageBase64?: string;
      imageType?:   string;
      creator?:     string;
    };

    const { name, symbol, description, website, twitter, telegram, imageBase64, imageType } = body;

    if (!name || !symbol) {
      return NextResponse.json({ error: "name and symbol are required" }, { status: 400 });
    }

    // Upload image first (optional)
    let imageCid = "";
    if (imageBase64 && imageType) {
      imageCid = await uploadImageToPinata(imageBase64, imageType, symbol);
    }

    // Always upload metadata JSON — meta field must be a valid CID
    const meta: Record<string, unknown> = {
      name,
      symbol,
      description: description ?? "",
      image:       imageCid ? `ipfs://${imageCid}` : "",
      website:     website  ?? null,
      twitter:     twitter  ?? null,
      telegram:    telegram ?? null,
    };

    const metaCid = await uploadJsonToPinata(meta, symbol);

    return NextResponse.json({
      cid:      metaCid,
      imageUrl: imageCid ? `https://ipfs.io/ipfs/${imageCid}` : "",
      metaUrl:  `https://ipfs.io/ipfs/${metaCid}`,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("[upload-meta]", msg);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
