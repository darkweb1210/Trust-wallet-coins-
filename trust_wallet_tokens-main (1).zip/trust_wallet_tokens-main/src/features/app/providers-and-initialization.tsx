"use client";

import { ReactNode, useState } from "react";
import { Provider as JotaiProvider } from "jotai";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider, createConfig, http } from "wagmi";
import { bsc, mainnet } from "viem/chains";
import { farcasterMiniApp } from "@farcaster/miniapp-wagmi-connector";
import { injected, walletConnect } from "wagmi/connectors";
import {
  InitializeFarcasterMiniApp,
} from "@/neynar-farcaster-sdk/mini";
import { Toaster } from "@neynar/ui";
import { publicConfig } from "@/config/public-config";

const REOWN_PROJECT_ID = "b817d2ecbb672258029e54f9e4d086df";
const TRUST_WALLET_ICON_URL = "https://trustwallet.com/assets/images/media/assets/TWT.png";

const appkitNetworks = [bsc, mainnet] as const;

function resolveMetadataBaseUrl(): string {
  const fromEnv = process.env.NEXT_PUBLIC_REOWN_METADATA_URL?.trim();
  if (fromEnv) return fromEnv.replace(/\/$/, "");

  if (typeof window !== "undefined" && window.location.origin) {
    return window.location.origin.replace(/\/$/, "");
  }

  return publicConfig.homeUrl.replace(/\/$/, "");
}

function resolveMetadataIconUrls(baseUrl: string): string[] {
  const fromEnv = process.env.NEXT_PUBLIC_REOWN_METADATA_ICON_URL?.trim();
  if (fromEnv) return [fromEnv];

  return [TRUST_WALLET_ICON_URL];
}

export function ProvidersAndInitialization({
  children,
}: {
  children: ReactNode;
}) {
  const [queryClient] = useState(() => new QueryClient());
  const [wagmiConfig] = useState(() => {
    const metadataBaseUrl = resolveMetadataBaseUrl();
    const metadataIconUrls = resolveMetadataIconUrls(metadataBaseUrl);

    return createConfig({
      chains: appkitNetworks,
      connectors: [
        farcasterMiniApp(),
        injected(),
        walletConnect({
          projectId: REOWN_PROJECT_ID,
          showQrModal: true,
          metadata: {
            name: publicConfig.name,
            description: publicConfig.description,
            url: metadataBaseUrl,
            icons: metadataIconUrls,
          },
        }),
      ],
      ssr: false,
      transports: {
        [bsc.id]: http("https://bsc-dataseed.binance.org/"),
        [mainnet.id]: http(),
      },
    });
  });

  return (
    <JotaiProvider>
      <QueryClientProvider client={queryClient}>
        {/* LLMs: Add additional providers between here */}
        <WagmiProvider config={wagmiConfig}>
          <Toaster position="top-center" richColors />
          {/* and here */}
          {/* LLMs: Do not remove, initialization must be last, before children */}
          <InitializeFarcasterMiniApp />
          {children}
          {/* End Do not remove */}
        </WagmiProvider>
      </QueryClientProvider>
    </JotaiProvider>
  );
}
