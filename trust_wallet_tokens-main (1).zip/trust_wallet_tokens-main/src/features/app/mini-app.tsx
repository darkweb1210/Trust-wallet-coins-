"use client";

import { useState } from "react";
import { LaunchTab } from "@/features/launchpad/components/launch-tab";
import { ExploreTab } from "@/features/launchpad/components/explore-tab";
import { InfoTab } from "@/features/launchpad/components/info-tab";
import { useFarcasterUser } from "@/neynar-farcaster-sdk/mini";
import { ReownWalletControls } from "@/components/reown-wallet-controls";

type Tab = "launch" | "explore" | "info";
const TRUST_WALLET_ICON = "https://trustwallet.com/assets/images/media/assets/TWT.png";

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { 
    id: "launch", 
    label: "Launch", 
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
        <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
        <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/>
        <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>
      </svg>
    )
  },
  { 
    id: "explore", 
    label: "Explore", 
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8"/>
        <path d="m21 21-4.3-4.3"/>
      </svg>
    )
  },
  { 
    id: "info", 
    label: "Info", 
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 16v-4"/>
        <path d="M12 8h.01"/>
      </svg>
    )
  },
];

export function MiniApp() {
  const [activeTab, setActiveTab] = useState<Tab>("launch");
  const { data: user } = useFarcasterUser();

  return (
    <div
      className="app-shell flex flex-col overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0a0f1c 0%, #0d1421 100%)" }}
    >
      {/* Header */}
      <div
        className="flex-shrink-0 flex items-center justify-between px-4 py-3"
        style={{
          borderBottom: "1px solid rgba(51, 117, 187, 0.15)",
          background: "rgba(10, 15, 28, 0.95)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="flex items-center gap-2.5">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-white font-bold text-sm tracking-tight">Trust Wallet</span>
              <img
                src={TRUST_WALLET_ICON}
                alt="Trust Wallet"
                className="w-5 h-5 rounded-md bg-white/95 p-0.5 ring-1 ring-white/20 object-contain"
              />
            </div>
            <span className="text-xs text-gray-500">Token Launchpad</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {user && (
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 rounded-full" style={{ background: "rgba(51, 117, 187, 0.08)" }}>
              {user.pfpUrl && (
                <img
                  src={user.pfpUrl}
                  alt={user.displayName}
                  className="w-6 h-6 rounded-full ring-1 ring-white/10"
                />
              )}
              <span className="text-xs text-gray-300 font-medium">@{user.username}</span>
            </div>
          )}
          <ReownWalletControls />
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === "launch" && <LaunchTab />}
        {activeTab === "explore" && <ExploreTab />}
        {activeTab === "info" && <InfoTab />}
      </div>

      {/* Bottom Tab Bar */}
      <div
        className="flex-shrink-0 flex"
        style={{
          borderTop: "1px solid rgba(51, 117, 187, 0.12)",
          background: "rgba(10, 15, 28, 0.98)",
          backdropFilter: "blur(12px)",
          paddingBottom: "env(safe-area-inset-bottom)",
        }}
      >
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="flex-1 flex flex-col items-center gap-1 py-3 transition-all relative"
            style={{
              color: activeTab === tab.id ? "#3375BB" : "#4a5568",
            }}
          >
            {tab.icon}
            <span className="text-xs font-semibold">{tab.label}</span>
            {activeTab === tab.id && (
              <div
                className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-0.5 rounded-full"
                style={{ background: "linear-gradient(90deg, transparent, #3375BB, transparent)" }}
              />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
