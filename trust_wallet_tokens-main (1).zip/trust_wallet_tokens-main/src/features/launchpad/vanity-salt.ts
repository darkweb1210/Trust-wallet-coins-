"use client";

// Vanity salt — matches algorithm from flap.sh official docs
// Standard Token V2 → address ends in "8888"
// Tax Token V3      → address ends in "7777"

import { FLAP_CONTRACTS, VANITY_SUFFIX_STANDARD, VANITY_SUFFIX_TAX } from "./constants";
import type { TokenVersion, VanityResult } from "./types";

function getTokenImpl(version: TokenVersion): `0x${string}` {
  return (
    version === "TOKEN_TAXED_V3"
      ? FLAP_CONTRACTS.TOKEN_IMPL_TAX_V3
      : FLAP_CONTRACTS.TOKEN_IMPL_STANDARD
  ) as `0x${string}`;
}

// Generate a random 32-byte hex string without generatePrivateKey
function randomSeed(): `0x${string}` {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return ("0x" +
    Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")) as `0x${string}`;
}

export async function computeVanitySalt(
  version: TokenVersion,
  onProgress?: (iterations: number) => void
): Promise<VanityResult> {
  const suffix    = version === "TOKEN_TAXED_V3" ? VANITY_SUFFIX_TAX : VANITY_SUFFIX_STANDARD;
  const tokenImpl = getTokenImpl(version);
  const portal    = FLAP_CONTRACTS.PORTAL as `0x${string}`;

  const { getContractAddress, keccak256, toBytes } = await import("viem");

  // EIP-1167 minimal proxy init bytecode (same as flap.sh docs)
  const bytecode = (
    "0x3d602d80600a3d3981f3363d3d373d3d3d363d73" +
    tokenImpl.slice(2).toLowerCase() +
    "5af43d82803e903d91602b57fd5bf3"
  ) as `0x${string}`;

  function predictAddress(salt: `0x${string}`): `0x${string}` {
    return getContractAddress({
      from:     portal,
      salt:     toBytes(salt),
      bytecode: bytecode,
      opcode:   "CREATE2",
    });
  }

  // Start from a random seed, hash-chain to find vanity suffix
  let salt       = keccak256(randomSeed()) as `0x${string}`;
  let iterations = 0;
  const BATCH    = 200;

  while (true) {
    for (let i = 0; i < BATCH; i++) {
      if (predictAddress(salt).toLowerCase().endsWith(suffix)) {
        return { salt, tokenAddress: predictAddress(salt), iterations };
      }
      salt = keccak256(salt) as `0x${string}`;
      iterations++;
    }
    onProgress?.(iterations);
    await new Promise<void>((r) => setTimeout(r, 0));
  }
}
