// Client-side helper — posts to /api/upload-meta which proxies to funcs.flap.sh/api/upload

export interface TokenMetaInput {
  name:         string;
  symbol:       string;
  description?: string;
  website?:     string;
  twitter?:     string;
  telegram?:    string;
  imageBase64?: string;
  imageType?:   string;
  creator?:     string;
}

export interface UploadMetaResult {
  cid:      string;
  imageUrl: string;
  metaUrl:  string;
}

export async function uploadTokenMeta(input: TokenMetaInput): Promise<UploadMetaResult> {
  const res = await fetch("/api/upload-meta", {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(input),
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({})) as { error?: string };
    throw new Error(data.error ?? `Upload failed with status ${res.status}`);
  }

  return res.json() as Promise<UploadMetaResult>;
}
