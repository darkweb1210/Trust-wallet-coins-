// ─── Flap.sh BSC Mainnet Contracts ────────────────────────────────────────────
// Verified from deployed contract addresses docs + on-chain data
export const FLAP_CONTRACTS = {
  PORTAL:              "0xe2cE6ab80874Fa9Fa2aAE65D277Dd6B8e65C9De0" as const,
  TOKEN_IMPL_STANDARD: "0x8b4329947e34b6d56d71a3385cac122bade7d78d" as const,
  TOKEN_IMPL_TAX_V3:   "0x024f18294970B5c76c0691b87f138A0317156422" as const,
} as const;

export const BSC_CHAIN_ID    = 56;
export const MIN_QUOTE_AMT_BNB = "0.0005";
export const DEFAULT_SECOND_LIQUIDITY_USDT = "1";

export const VANITY_SUFFIX_STANDARD = "8888";
export const VANITY_SUFFIX_TAX      = "7777";

// ─── Enum values — verified from REAL on-chain transaction decoding ───────────
// Decoded from actual successful txs on BSC (e.g. 0x4fec4f98..., 0x21851e51...)
//
// dexThresh:    1  (TWO_THIRDS — confirmed from 4 real txs)
// migratorType: 1  (V2_MIGRATOR — used in all observed token creations)
// tokenVersion: 6  (TOKEN_TAXED_V3) or 2 (TOKEN_V2_PERMIT)
// dexId:        0  (DEX0)
// lpFeeProfile: 0  (STANDARD)

export const TOKEN_VERSION = {
  TOKEN_V2_PERMIT: 2,
  TOKEN_TAXED_V3:  6,
} as const;

export const DEX_THRESH = {
  TWO_THIRDS: 1, // ← 1, verified from real txs
} as const;

export const MIGRATOR_TYPE = {
  V2_MIGRATOR: 1, // ← 1 for all token types, verified from real txs
} as const;

export const DEX_ID = {
  DEX0: 0,
} as const;

export const LP_FEE_PROFILE = {
  STANDARD: 0,
} as const;

// Tax bps — must sum to 10000 for tax tokens; all 0 for standard
export const TAX_DIST_MKT_BPS       = 10000;
export const TAX_DIST_DEFLATION_BPS = 0;
export const TAX_DIST_DIVIDEND_BPS  = 0;
export const TAX_DIST_LP_BPS        = 0;

// ─── PancakeSwap V3 — BSC Mainnet ─────────────────────────────────────────────
// NonfungiblePositionManager verified on BSC mainnet
export const PANCAKE_V3_NFT_MANAGER = "0x46A15B0b27311cedF172AB29E4f4766fbE7F4364" as `0x${string}`;
// PancakeSwap V3 smart router on BSC mainnet
export const PANCAKE_V3_SWAP_ROUTER = "0x13f4EA83D0bd40E75C8222255bc855a974568Dd4" as `0x${string}`;
// USDT BEP-20 (18 decimals) on BSC mainnet
export const USDT_BSC               = "0x55d398326f99059fF775485246999027B3197955" as `0x${string}`;
// 0.01% fee tier
export const PANCAKE_V3_FEE         = 100;
// sqrt(1) * 2^96 — initial price 1 token = 1 USDT (both 18 dec)
export const SQRT_PRICE_ONE_X96     = 79228162514264337593543950336n;
// Around 1.0 with ~0.1% band (roughly 0.999 - 1.001)
export const PANCAKE_V3_TICK_LOWER  = -10;
export const PANCAKE_V3_TICK_UPPER  = 10;
// Use 0 min-out so the first post-launch sell doesn't revert on thin/new liquidity.
export const SELL_MIN_OUT_USDT      = "0";
export const PORTAL_NEW_TOKEN_SELECTOR = "0x8cb5772c";

export const ERC20_APPROVE_ABI = [
  {
    inputs: [
      { internalType: "address", name: "spender", type: "address" },
      { internalType: "uint256", name: "amount",  type: "uint256" },
    ],
    name: "approve",
    outputs: [{ internalType: "bool", name: "", type: "bool" }],
    stateMutability: "nonpayable",
    type: "function",
  },
] as const;

export const ERC20_METADATA_ABI = [
  {
    inputs: [],
    name: "name",
    outputs: [{ internalType: "string", name: "", type: "string" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "symbol",
    outputs: [{ internalType: "string", name: "", type: "string" }],
    stateMutability: "view",
    type: "function",
  },
] as const;

// ABI for createAndInitializePoolIfNecessary, mint, and multicall on the
// PancakeSwap V3 NonfungiblePositionManager
export const PANCAKE_V3_NFT_ABI = [
  {
    inputs: [
      { internalType: "address", name: "token0",       type: "address" },
      { internalType: "address", name: "token1",       type: "address" },
      { internalType: "uint24",  name: "fee",          type: "uint24"  },
      { internalType: "uint160", name: "sqrtPriceX96", type: "uint160" },
    ],
    name: "createAndInitializePoolIfNecessary",
    outputs: [{ internalType: "address", name: "pool", type: "address" }],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [
      {
        components: [
          { internalType: "address", name: "token0",         type: "address" },
          { internalType: "address", name: "token1",         type: "address" },
          { internalType: "uint24",  name: "fee",            type: "uint24"  },
          { internalType: "int24",   name: "tickLower",      type: "int24"   },
          { internalType: "int24",   name: "tickUpper",      type: "int24"   },
          { internalType: "uint256", name: "amount0Desired", type: "uint256" },
          { internalType: "uint256", name: "amount1Desired", type: "uint256" },
          { internalType: "uint256", name: "amount0Min",     type: "uint256" },
          { internalType: "uint256", name: "amount1Min",     type: "uint256" },
          { internalType: "address", name: "recipient",      type: "address" },
          { internalType: "uint256", name: "deadline",       type: "uint256" },
        ],
        internalType: "struct INonfungiblePositionManager.MintParams",
        name: "params",
        type: "tuple",
      },
    ],
    name: "mint",
    outputs: [
      { internalType: "uint256", name: "tokenId",   type: "uint256" },
      { internalType: "uint128", name: "liquidity", type: "uint128" },
      { internalType: "uint256", name: "amount0",   type: "uint256" },
      { internalType: "uint256", name: "amount1",   type: "uint256" },
    ],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ internalType: "bytes[]", name: "data", type: "bytes[]" }],
    name: "multicall",
    outputs: [{ internalType: "bytes[]", name: "results", type: "bytes[]" }],
    stateMutability: "payable",
    type: "function",
  },
] as const;

export const PANCAKE_V3_SWAP_ROUTER_ABI = [
  {
    inputs: [
      {
        components: [
          { internalType: "address", name: "tokenIn",           type: "address" },
          { internalType: "address", name: "tokenOut",          type: "address" },
          { internalType: "uint24",  name: "fee",               type: "uint24" },
          { internalType: "address", name: "recipient",         type: "address" },
          { internalType: "uint256", name: "amountIn",          type: "uint256" },
          { internalType: "uint256", name: "amountOutMinimum",  type: "uint256" },
          { internalType: "uint160", name: "sqrtPriceLimitX96", type: "uint160" },
        ],
        internalType: "struct ISwapRouter.ExactInputSingleParams",
        name: "params",
        type: "tuple",
      },
    ],
    name: "exactInputSingle",
    outputs: [{ internalType: "uint256", name: "amountOut", type: "uint256" }],
    stateMutability: "payable",
    type: "function",
  },
] as const;

// ─── Portal ABI ───────────────────────────────────────────────────────────────
// Function selector verified: 0x8cb5772c = newTokenV6(...)
// taxDuration + antiFarmerDuration = uint64
// meta = bare IPFS CID string (NO "ipfs://" prefix) — verified from real txs
export const PORTAL_ABI = [
  {
    inputs: [
      {
        components: [
          { internalType: "string",  name: "name",                type: "string"  },
          { internalType: "string",  name: "symbol",              type: "string"  },
          { internalType: "string",  name: "meta",                type: "string"  },
          { internalType: "uint8",   name: "dexThresh",           type: "uint8"   },
          { internalType: "bytes32", name: "salt",                type: "bytes32" },
          { internalType: "uint8",   name: "migratorType",        type: "uint8"   },
          { internalType: "address", name: "quoteToken",          type: "address" },
          { internalType: "uint256", name: "quoteAmt",            type: "uint256" },
          { internalType: "address", name: "beneficiary",         type: "address" },
          { internalType: "bytes",   name: "permitData",          type: "bytes"   },
          { internalType: "bytes32", name: "extensionID",         type: "bytes32" },
          { internalType: "bytes",   name: "extensionData",       type: "bytes"   },
          { internalType: "uint8",   name: "dexId",               type: "uint8"   },
          { internalType: "uint8",   name: "lpFeeProfile",        type: "uint8"   },
          { internalType: "uint16",  name: "buyTaxRate",          type: "uint16"  },
          { internalType: "uint16",  name: "sellTaxRate",         type: "uint16"  },
          { internalType: "uint64",  name: "taxDuration",         type: "uint64"  },
          { internalType: "uint64",  name: "antiFarmerDuration",  type: "uint64"  },
          { internalType: "uint16",  name: "mktBps",              type: "uint16"  },
          { internalType: "uint16",  name: "deflationBps",        type: "uint16"  },
          { internalType: "uint16",  name: "dividendBps",         type: "uint16"  },
          { internalType: "uint16",  name: "lpBps",               type: "uint16"  },
          { internalType: "uint256", name: "minimumShareBalance", type: "uint256" },
          { internalType: "address", name: "dividendToken",       type: "address" },
          { internalType: "address", name: "commissionReceiver",  type: "address" },
          { internalType: "uint8",   name: "tokenVersion",        type: "uint8"   },
        ],
        internalType: "struct IPortalTypes.NewTokenV6Params",
        name: "params",
        type: "tuple",
      },
    ],
    name: "newTokenV6",
    outputs: [{ internalType: "address", name: "token", type: "address" }],
    stateMutability: "payable",
    type: "function",
  },
] as const;
