"use client";

import type { LaunchResult } from "@/features/launchpad/types";

function isLaunchResult(value: unknown): value is LaunchResult {
  if (!value || typeof value !== "object") {
    return false;
  }

  const record = value as Partial<LaunchResult>;
  return (
    typeof record.tokenAddress === "string" &&
    typeof record.txHash === "string" &&
    typeof record.name === "string" &&
    typeof record.symbol === "string" &&
    typeof record.creator === "string" &&
    typeof record.timestamp === "number"
  );
}

const STORAGE_KEY = "trust-wallet-launchpad-launches";
export const WEBSITE_LAUNCHES_UPDATED_EVENT = "website-launches-updated";

export function readStoredLaunches(): LaunchResult[] {
  if (typeof window === "undefined") {
    return [];
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed.filter(isLaunchResult).sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export function storeLaunchRecord(record: LaunchResult) {
  if (typeof window === "undefined") {
    return;
  }

  const launches = readStoredLaunches().filter(
    (existing) =>
      existing.txHash.toLowerCase() !== record.txHash.toLowerCase() &&
      existing.tokenAddress.toLowerCase() !== record.tokenAddress.toLowerCase(),
  );

  window.localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify([record, ...launches]),
  );

  window.dispatchEvent(new CustomEvent(WEBSITE_LAUNCHES_UPDATED_EVENT, { detail: record }));
}