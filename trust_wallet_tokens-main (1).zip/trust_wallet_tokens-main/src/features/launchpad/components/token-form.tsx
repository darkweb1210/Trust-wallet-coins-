"use client";

import { useState, useRef, type ChangeEvent, type FormEvent } from "react";
import type { TokenFormData, TokenVersion } from "@/features/launchpad/types";
import {
  DEFAULT_SECOND_LIQUIDITY_USDT,
  MIN_QUOTE_AMT_BNB,
} from "@/features/launchpad/constants";

const DEFAULT: TokenFormData = {
  name: "", symbol: "", description: "",
  website: "", twitter: "", telegram: "",
  imageFile: null, imagePreviewUrl: null,
  tokenVersion: "TOKEN_V2_PERMIT",
  buyTaxRate: 0, sellTaxRate: 0, taxDuration: 30,
  quoteAmt: MIN_QUOTE_AMT_BNB,
  secondLiquidityUsdt: DEFAULT_SECOND_LIQUIDITY_USDT,
};

const NUMERIC_FIELDS = new Set(["buyTaxRate", "sellTaxRate", "taxDuration"]);

function normalizeDecimalInput(value: string): string {
  let normalized = value.replace(/,/g, ".").trim();

  if (normalized.startsWith(".")) {
    normalized = `0${normalized}`;
  }

  if (normalized.endsWith(".")) {
    normalized = normalized.slice(0, -1);
  }

  return normalized;
}

function isValidPositiveDecimal(value: string): boolean {
  if (!/^(?:\d+|\d+\.\d{1,18})$/.test(value)) {
    return false;
  }

  return Number(value) > 0;
}

export function TokenForm({ onSubmit }: { onSubmit: (d: TokenFormData) => void }) {
  const [form, setForm]           = useState<TokenFormData>(DEFAULT);
  const [showSocials, setShowSocials] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const isTax = form.tokenVersion === "TOKEN_TAXED_V3";

  function set(field: keyof TokenFormData, value: unknown) {
    setForm((p) => ({ ...p, [field]: value }));
  }

  function handleChange(e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target;

    if (name === "quoteAmt" || name === "secondLiquidityUsdt") {
      set(name as keyof TokenFormData, normalizeDecimalInput(value));
      return;
    }

    set(
      name as keyof TokenFormData,
      NUMERIC_FIELDS.has(name) ? Number(value) : value,
    );
  }

  function handleVersion(v: TokenVersion) {
    setForm((p) => ({
      ...p,
      tokenVersion: v,
      buyTaxRate:  v === "TOKEN_V2_PERMIT" ? 0 : p.buyTaxRate,
      sellTaxRate: v === "TOKEN_V2_PERMIT" ? 0 : p.sellTaxRate,
    }));
  }

  function handleImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((p) => ({ ...p, imageFile: file, imagePreviewUrl: URL.createObjectURL(file) }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();

    const normalizedQuoteAmt = normalizeDecimalInput(form.quoteAmt);
    const normalizedSecondLiquidity = normalizeDecimalInput(form.secondLiquidityUsdt);

    if (!isValidPositiveDecimal(normalizedQuoteAmt)) {
      return;
    }

    if (!isValidPositiveDecimal(normalizedSecondLiquidity)) {
      return;
    }

    onSubmit({
      ...form,
      quoteAmt: normalizedQuoteAmt,
      secondLiquidityUsdt: normalizedSecondLiquidity,
    });
  }

  const canSubmit =
    !!form.name.trim() &&
    !!form.symbol.trim() &&
    isValidPositiveDecimal(normalizeDecimalInput(form.quoteAmt)) &&
    isValidPositiveDecimal(normalizeDecimalInput(form.secondLiquidityUsdt));

  return (
    <form onSubmit={handleSubmit} className="space-y-5 pb-8">

      {/* ── Logo Upload ── */}
      <div className="flex flex-col items-center gap-3">
        <button type="button" onClick={() => fileRef.current?.click()}
          className="w-24 h-24 rounded-2xl flex items-center justify-center overflow-hidden transition-all shadow-lg"
          style={{
            border: form.imagePreviewUrl ? "2px solid rgba(51, 117, 187, 0.6)" : "2px dashed rgba(51, 117, 187, 0.3)",
            background: "rgba(51, 117, 187, 0.06)",
          }}>
          {form.imagePreviewUrl
            ? <img src={form.imagePreviewUrl} alt="logo" className="w-full h-full object-cover rounded-2xl" />
            : <div className="text-center">
                <svg className="w-8 h-8 mx-auto mb-1" style={{ color: "#3375BB" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
                  <circle cx="9" cy="9" r="2"/>
                  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
                </svg>
                <div className="text-xs font-medium" style={{ color: "#3375BB" }}>Add Logo</div>
              </div>
          }
        </button>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleImage} />
        <p className="text-xs text-gray-500">Recommended 512x512</p>
      </div>

      {/* ── Token Name + Symbol ── */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <label className="text-xs font-semibold tracking-wide text-gray-400">TOKEN NAME *</label>
          <input
            name="name" value={form.name} onChange={handleChange} required
            placeholder="My Token"
            className="w-full px-3.5 py-3 rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none transition-all"
            style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
            onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.5)")}
            onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.12)")}
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold tracking-wide text-gray-400">SYMBOL *</label>
          <input
            name="symbol" value={form.symbol} onChange={handleChange} required maxLength={10}
            placeholder="MTK"
            className="w-full px-3.5 py-3 rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none uppercase transition-all"
            style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
            onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.5)")}
            onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.12)")}
          />
        </div>
      </div>

      {/* ── Description ── */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold tracking-wide text-gray-400">DESCRIPTION</label>
        <textarea
          name="description" value={form.description} onChange={handleChange}
          placeholder="What is your token about?"
          rows={2}
          className="w-full px-3.5 py-3 rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none resize-none transition-all"
          style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
          onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.5)")}
          onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.12)")}
        />
      </div>

      {/* ── Token Type: Standard V2 vs Tax V3 ── */}
      <div className="space-y-2">
        <label className="text-xs font-semibold tracking-wide text-gray-400">TOKEN TYPE</label>
        <div className="grid grid-cols-2 gap-3">
          {([
            { v: "TOKEN_V2_PERMIT", emoji: "🪙", title: "Token V2", sub: "Standard ERC-20" },
            { v: "TOKEN_TAXED_V3",  emoji: "💎", title: "Tax Token V3", sub: "Buy / sell tax" },
          ] as const).map(({ v, emoji, title, sub }) => (
            <button key={v} type="button" onClick={() => handleVersion(v)}
              className="py-4 rounded-xl text-sm font-semibold transition-all"
              style={{
                border: form.tokenVersion === v
                  ? "1px solid rgba(51, 117, 187, 0.6)"
                  : "1px solid rgba(51, 117, 187, 0.1)",
                background: form.tokenVersion === v
                  ? "rgba(51, 117, 187, 0.12)"
                  : "rgba(51, 117, 187, 0.04)",
                color: form.tokenVersion === v ? "#3375BB" : "#666",
              }}>
              <div className="w-10 h-10 mx-auto mb-2 rounded-lg flex items-center justify-center" style={{ background: form.tokenVersion === v ? "rgba(51, 117, 187, 0.2)" : "rgba(51, 117, 187, 0.08)" }}>
                <span className="text-xl">{emoji}</span>
              </div>
              <div>{title}</div>
              <div className="text-xs font-normal mt-1" style={{ color: form.tokenVersion === v ? "rgba(51, 117, 187, 0.8)" : "#555" }}>{sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* ── Tax Config ── */}
      {isTax && (
        <div className="space-y-3 p-4 rounded-xl" style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.15)" }}>
          <p className="text-xs font-bold tracking-wide" style={{ color: "#3375BB" }}>TAX CONFIGURATION</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { field: "buyTaxRate",  label: "Buy Tax"  },
              { field: "sellTaxRate", label: "Sell Tax" },
            ].map(({ field, label }) => (
              <div key={field} className="space-y-1">
                <label className="text-xs text-gray-500">{label} (max 10%)</label>
                <div className="relative">
                  <input
                    name={field} type="number" min={0} max={1000} step={50}
                    value={form[field as keyof TokenFormData] as number}
                    onChange={handleChange}
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-sm text-white focus:outline-none"
                    style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-600">bps</span>
                </div>
                <p className="text-xs text-gray-700">
                  {((form[field as keyof TokenFormData] as number) / 100).toFixed(1)}%
                </p>
              </div>
            ))}
          </div>
          <div className="space-y-1">
            <label className="text-xs text-gray-500">Tax Duration (days)</label>
            <input
              name="taxDuration" type="number" min={1} max={365}
              value={form.taxDuration} onChange={handleChange}
              className="w-full px-3 py-2.5 rounded-xl text-sm text-white focus:outline-none"
              style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
            />
          </div>
        </div>
      )}

      {/* ── Initial Liquidity ── */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold tracking-wide text-gray-400">INITIAL LIQUIDITY</label>
        <div className="relative">
          <input
            name="quoteAmt" type="number" min={MIN_QUOTE_AMT_BNB} step="0.0001"
            value={form.quoteAmt} onChange={handleChange} required
            className="w-full px-3.5 py-3 pr-16 rounded-xl text-sm text-white focus:outline-none transition-all"
            style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
            onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.5)")}
            onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.12)")}
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold px-2 py-1 rounded-md" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.1)" }}>BNB</span>
        </div>
        {!isValidPositiveDecimal(normalizeDecimalInput(form.quoteAmt)) && form.quoteAmt.length > 0 && (
          <p className="text-xs text-amber-400">
            Enter a valid BNB amount like 0.0005 or 1.25.
          </p>
        )}
        <p className="text-xs text-gray-500">Min {MIN_QUOTE_AMT_BNB} BNB · Funds the bonding curve</p>
      </div>

      <div
        className="space-y-3 p-4 rounded-2xl"
        style={{ background: "linear-gradient(180deg, rgba(51, 117, 187, 0.09) 0%, rgba(51, 117, 187, 0.03) 100%)", border: "1px solid rgba(51, 117, 187, 0.14)" }}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <label className="text-xs font-semibold tracking-wide text-gray-400">SECOND LIQUIDITY PAIR</label>
            <p className="text-sm font-semibold text-white mt-1">Deploy a PancakeSwap V3 TOKEN/USDT pool</p>
            <p className="text-xs text-gray-500 mt-1">This app adds matching token liquidity against USDT at a 1:1 starting ratio.</p>
          </div>
          <span className="text-[11px] px-2.5 py-1 rounded-full font-semibold" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.12)" }}>USDT only</span>
        </div>

        <div className="relative">
          <input
            name="secondLiquidityUsdt"
            type="text"
            inputMode="decimal"
            value={form.secondLiquidityUsdt}
            onChange={handleChange}
            required
            className="w-full px-3.5 py-3 pr-16 rounded-xl text-sm text-white focus:outline-none transition-all"
            style={{ background: "rgba(10, 15, 28, 0.45)", border: "1px solid rgba(51, 117, 187, 0.12)" }}
            onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.5)")}
            onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.12)")}
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold px-2 py-1 rounded-md" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.1)" }}>USDT</span>
        </div>
        {!isValidPositiveDecimal(normalizeDecimalInput(form.secondLiquidityUsdt)) && form.secondLiquidityUsdt.length > 0 && (
          <p className="text-xs text-amber-400">
            Enter a valid decimal amount like 1 or 1.25 (no scientific notation).
          </p>
        )}

        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "TOKEN", value: form.secondLiquidityUsdt },
            { label: "USDT", value: form.secondLiquidityUsdt },
            { label: "RATIO", value: "1 : 1" },
          ].map((item) => (
            <div key={item.label} className="rounded-xl px-3 py-2.5" style={{ background: "rgba(10, 15, 28, 0.38)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
              <div className="text-[10px] font-semibold tracking-wide text-gray-500">{item.label}</div>
              <div className="text-sm font-semibold text-white mt-1">{item.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Social Links ── */}
      <button type="button" onClick={() => setShowSocials(v => !v)}
        className="flex items-center gap-2 text-xs font-medium transition-colors px-3 py-2 rounded-lg"
        style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.06)" }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: showSocials ? "rotate(90deg)" : "rotate(0deg)", transition: "transform 0.2s" }}>
          <path d="m9 18 6-6-6-6"/>
        </svg>
        Social links (optional)
      </button>
      {showSocials && (
        <div className="space-y-3 p-4 rounded-xl" style={{ background: "rgba(51, 117, 187, 0.04)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
          {[
            { name: "website",  placeholder: "https://yourtoken.xyz", icon: "🌐" },
            { name: "twitter",  placeholder: "@yourhandle", icon: "𝕏" },
            { name: "telegram", placeholder: "@yourgroup", icon: "✈️" },
          ].map(({ name, placeholder, icon }) => (
            <div key={name} className="space-y-1.5">
              <label className="text-xs text-gray-400 capitalize flex items-center gap-1.5">
                <span>{icon}</span> {name}
              </label>
              <input
                name={name} value={form[name as keyof TokenFormData] as string} onChange={handleChange}
                placeholder={placeholder}
                className="w-full px-3.5 py-2.5 rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none transition-all"
                style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.1)" }}
                onFocus={e => (e.target.style.borderColor = "rgba(51, 117, 187, 0.4)")}
                onBlur={e  => (e.target.style.borderColor = "rgba(51, 117, 187, 0.1)")}
              />
            </div>
          ))}
        </div>
      )}

      {/* ── Launch Button ── */}
      <button
        type="submit"
        disabled={!canSubmit}
        className="w-full py-4 rounded-2xl font-bold text-base transition-all flex items-center justify-center gap-2"
        style={{
          background: canSubmit
            ? "linear-gradient(135deg, #3375BB 0%, #0B68C4 100%)"
            : "rgba(51, 117, 187, 0.15)",
          color:      canSubmit ? "#ffffff" : "#555",
          boxShadow:  canSubmit ? "0 4px 20px rgba(51, 117, 187, 0.35)" : "none",
          cursor:     canSubmit ? "pointer" : "not-allowed",
        }}
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
          <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
          <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/>
          <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>
        </svg>
        Launch Token on BSC
      </button>

      <p className="text-center text-xs text-gray-500 flex items-center justify-center gap-2">
        <img src="https://trustwallet.com/assets/images/media/assets/TWT.png" alt="Trust Wallet" className="w-4 h-4 object-contain" />
        Secured by Trust Wallet · Bonding curve + USDT pair launch
      </p>
    </form>
  );
}


