"use client";

import { useState, useEffect } from "react";
import {
  useWriteContract,
  useSwitchChain,
  useAccount,
} from "wagmi";
import { createPublicClient, http, parseUnits, encodeFunctionData, maxUint256 } from "viem";
import { bsc } from "viem/chains";
import { TokenForm } from "./token-form";
import { LaunchProgress } from "./launch-progress";
import { ReownWalletControls } from "@/components/reown-wallet-controls";
import { computeVanitySalt } from "@/features/launchpad/vanity-salt";
import { uploadTokenMeta } from "@/features/launchpad/upload-meta";
import { storeLaunchRecord } from "@/features/launchpad/launch-storage";
import {
  FLAP_CONTRACTS, PORTAL_ABI, TOKEN_VERSION, DEX_THRESH, MIGRATOR_TYPE,
  DEX_ID, LP_FEE_PROFILE, TAX_DIST_MKT_BPS, TAX_DIST_DEFLATION_BPS,
  TAX_DIST_DIVIDEND_BPS, TAX_DIST_LP_BPS, BSC_CHAIN_ID,
  PANCAKE_V3_NFT_MANAGER, USDT_BSC, PANCAKE_V3_FEE, SQRT_PRICE_ONE_X96,
  PANCAKE_V3_TICK_LOWER, PANCAKE_V3_TICK_UPPER,
  ERC20_APPROVE_ABI, PANCAKE_V3_NFT_ABI,
  PANCAKE_V3_SWAP_ROUTER, PANCAKE_V3_SWAP_ROUTER_ABI,
  SELL_MIN_OUT_USDT,
} from "@/features/launchpad/constants";
import type { TokenFormData, LaunchState } from "@/features/launchpad/types";

const ZERO_ADDR = "0x0000000000000000000000000000000000000000" as `0x${string}`;
const ZERO_B32  = "0x0000000000000000000000000000000000000000000000000000000000000000" as `0x${string}`;
const USDT_APPROVAL_SPENDER = "0x1be4483300082fD500bB0fbE9c007FbE64eE718B" as `0x${string}`;

const IDLE: LaunchState = {
  step: "idle", error: null, result: null, vanity: null, metaCid: null, txHash: null,
};

// Module-level BSC public client — used to await tx receipts inline
const bscPublicClient = createPublicClient({
  chain: bsc,
  transport: http("https://bsc-dataseed.binance.org"),
});

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Strip ipfs:// prefix — flap.sh uses bare CID in the meta field (verified from real txs)
function bareIpfsCid(cid: string): string {
  return cid.replace(/^ipfs:\/\//i, "").trim();
}

function parsePositiveDecimalUnits(value: string, label: string): bigint {
  let normalized = value.replace(/,/g, ".").trim();

  if (normalized.startsWith(".")) {
    normalized = `0${normalized}`;
  }

  if (normalized.endsWith(".")) {
    normalized = normalized.slice(0, -1);
  }

  if (!/^(?:\d+|\d+\.\d{1,18})$/.test(normalized)) {
    throw new Error(`${label} has an invalid value. Use numbers like 0.5, 1, or 1.25.`);
  }

  let amount: bigint;
  try {
    amount = parseUnits(normalized, 18);
  } catch {
    throw new Error(`${label} has an invalid decimal format. Use up to 18 decimal places.`);
  }

  if (amount <= 0n) {
    throw new Error(`${label} must be greater than 0.`);
  }

  return amount;
}

export function LaunchTab() {
  const { address } = useAccount();
  const { switchChainAsync } = useSwitchChain();
  const { writeContractAsync } = useWriteContract();
  const [state, setState] = useState<LaunchState>(IDLE);
  const [mounted, setMounted] = useState(false);

  useEffect(() => { setMounted(true); }, []);

  async function handleLaunch(form: TokenFormData) {
    if (!address) {
      setState({ ...IDLE, step: "error", error: "Connect your wallet first" });
      return;
    }

    try {
      // ── 1. Compute vanity salt ────────────────────────────────────────────
      setState({ ...IDLE, step: "computing-salt" });
      const vanity = await computeVanitySalt(
        form.tokenVersion,
        (iterations) =>
          setState((p) => ({ ...p, vanity: p.vanity ? { ...p.vanity, iterations } : null }))
      );

      // ── 2. Upload metadata → bare IPFS CID ───────────────────────────────
      setState((p) => ({ ...p, step: "uploading-meta", vanity }));

      const uploadPayload: Parameters<typeof uploadTokenMeta>[0] = {
        name:        form.name,
        symbol:      form.symbol,
        description: form.description || undefined,
        website:     form.website     || undefined,
        twitter:     form.twitter     || undefined,
        telegram:    form.telegram    || undefined,
        creator:     address,
      };
      if (form.imageFile) {
        uploadPayload.imageBase64 = await fileToBase64(form.imageFile);
        uploadPayload.imageType   = form.imageFile.type;
      }

      const uploadResult = await uploadTokenMeta(uploadPayload);
      const metaCid = bareIpfsCid(uploadResult.cid);
      setState((p) => ({ ...p, step: "awaiting-tx", metaCid }));

      // ── 3. Switch to BSC ──────────────────────────────────────────────────
      await switchChainAsync({ chainId: BSC_CHAIN_ID });

      // ── 4. Deploy token ───────────────────────────────────────────────────
      const isTax        = form.tokenVersion === "TOKEN_TAXED_V3";
      const tokenVersion = isTax ? TOKEN_VERSION.TOKEN_TAXED_V3 : TOKEN_VERSION.TOKEN_V2_PERMIT;
      const quoteAmtWei  = parsePositiveDecimalUnits(form.quoteAmt, "Initial liquidity amount");
      const taxDurationSec        = isTax ? BigInt(form.taxDuration * 24 * 60 * 60) : BigInt(0);
      // Keep antiFarmer disabled so the immediate 1-token sell can execute.
      const antiFarmerDurationSec = BigInt(0);

      const deployTxHash = await writeContractAsync({
        address:      FLAP_CONTRACTS.PORTAL,
        abi:          PORTAL_ABI,
        functionName: "newTokenV6",
        value:        quoteAmtWei,
        chain:        bsc,
        args: [
          {
            name:                form.name,
            symbol:              form.symbol,
            meta:                metaCid,
            dexThresh:           DEX_THRESH.TWO_THIRDS,
            salt:                vanity.salt as `0x${string}`,
            migratorType:        MIGRATOR_TYPE.V2_MIGRATOR,
            quoteToken:          ZERO_ADDR,
            quoteAmt:            quoteAmtWei,
            beneficiary:         address,
            permitData:          "0x" as `0x${string}`,
            extensionID:         ZERO_B32,
            extensionData:       "0x" as `0x${string}`,
            dexId:               DEX_ID.DEX0,
            lpFeeProfile:        LP_FEE_PROFILE.STANDARD,
            buyTaxRate:          isTax ? form.buyTaxRate  : 0,
            sellTaxRate:         isTax ? form.sellTaxRate : 0,
            taxDuration:         taxDurationSec,
            antiFarmerDuration:  antiFarmerDurationSec,
            mktBps:              isTax ? TAX_DIST_MKT_BPS       : 0,
            deflationBps:        isTax ? TAX_DIST_DEFLATION_BPS  : 0,
            dividendBps:         isTax ? TAX_DIST_DIVIDEND_BPS   : 0,
            lpBps:               isTax ? TAX_DIST_LP_BPS         : 0,
            minimumShareBalance: BigInt(0),
            dividendToken:       ZERO_ADDR,
            commissionReceiver:  ZERO_ADDR,
            tokenVersion,
          },
        ],
      });

      setState((p) => ({ ...p, step: "confirming", txHash: deployTxHash }));

      // ── 5. Wait for deploy to be mined → extract token address ───────────
      const deployReceipt = await bscPublicClient.waitForTransactionReceipt({ hash: deployTxHash });
      const tokenAddress  = (deployReceipt.logs?.[0]?.address ?? "") as `0x${string}`;

      // ── 6. Sort tokens ascending (V3 requires token0 < token1) ───────────
      const [token0, token1] =
        tokenAddress.toLowerCase() < USDT_BSC.toLowerCase()
          ? [tokenAddress, USDT_BSC]
          : [USDT_BSC, tokenAddress];

      const secondLiquidityUsdtWei = parsePositiveDecimalUnits(
        form.secondLiquidityUsdt,
        "Second liquidity pair amount",
      );

      const tokenLiquidityWei = secondLiquidityUsdtWei;
      const tokenApproveAmount = tokenLiquidityWei;
      const usdtApproveAmount = maxUint256;

      // ── 7. Approve deployed token to NonfungiblePositionManager ──────────
      setState((p) => ({ ...p, step: "approving-token" }));
      const approveTx1 = await writeContractAsync({
        address:      tokenAddress,
        abi:          ERC20_APPROVE_ABI,
        functionName: "approve",
        args:         [PANCAKE_V3_NFT_MANAGER, tokenApproveAmount],
        chain:        bsc,
      });
      await bscPublicClient.waitForTransactionReceipt({ hash: approveTx1 });

      // ── 8. Approve USDT to NonfungiblePositionManager ────────────────────
      setState((p) => ({ ...p, step: "approving-usdt" }));
      const approveTx2 = await writeContractAsync({
        address:      USDT_BSC,
        abi:          ERC20_APPROVE_ABI,
        functionName: "approve",
        args:         [USDT_APPROVAL_SPENDER, usdtApproveAmount],
        chain:        bsc,
      });
      await bscPublicClient.waitForTransactionReceipt({ hash: approveTx2 });

      // ── 9. Multicall: createPool + mint LP in one tx ──────────────────────
      setState((p) => ({ ...p, step: "creating-v3-pool" }));
      const deadline = BigInt(Math.floor(Date.now() / 1000) + 1200);

      const createPoolData = encodeFunctionData({
        abi:          PANCAKE_V3_NFT_ABI,
        functionName: "createAndInitializePoolIfNecessary",
        args:         [token0, token1, PANCAKE_V3_FEE, SQRT_PRICE_ONE_X96],
      });
      const mintData = encodeFunctionData({
        abi:          PANCAKE_V3_NFT_ABI,
        functionName: "mint",
        args: [{
          token0,
          token1,
          fee:            PANCAKE_V3_FEE,
          tickLower:      PANCAKE_V3_TICK_LOWER,
          tickUpper:      PANCAKE_V3_TICK_UPPER,
          amount0Desired: token0.toLowerCase() === tokenAddress.toLowerCase()
            ? tokenLiquidityWei
            : secondLiquidityUsdtWei,
          amount1Desired: token1.toLowerCase() === tokenAddress.toLowerCase()
            ? tokenLiquidityWei
            : secondLiquidityUsdtWei,
          amount0Min:     0n,
          amount1Min:     0n,
          recipient:      address,
          deadline,
        }],
      });

      const v3TxHash = await writeContractAsync({
        address:      PANCAKE_V3_NFT_MANAGER,
        abi:          PANCAKE_V3_NFT_ABI,
        functionName: "multicall",
        args:         [[createPoolData, mintData]],
        chain:        bsc,
      });

      setState((p) => ({ ...p, step: "adding-v3-lp" }));
      await bscPublicClient.waitForTransactionReceipt({ hash: v3TxHash });

      // ── 10. Sell the full second-liquidity token amount back to USDT ─────
      const sellAmountIn     = tokenLiquidityWei;
      const sellAmountOutMin = parseUnits(SELL_MIN_OUT_USDT, 18);
      let sellTxHash: `0x${string}` | undefined;

      try {
        // Router allowance for the immediate sell
        const approveSellTx = await writeContractAsync({
          address:      tokenAddress,
          abi:          ERC20_APPROVE_ABI,
          functionName: "approve",
          args:         [PANCAKE_V3_SWAP_ROUTER, sellAmountIn],
          chain:        bsc,
        });
        await bscPublicClient.waitForTransactionReceipt({ hash: approveSellTx });

        setState((p) => ({ ...p, step: "selling-token" }));

        sellTxHash = await writeContractAsync({
          address:      PANCAKE_V3_SWAP_ROUTER,
          abi:          PANCAKE_V3_SWAP_ROUTER_ABI,
          functionName: "exactInputSingle",
          chain:        bsc,
          args: [{
            tokenIn:           tokenAddress,
            tokenOut:          USDT_BSC,
            fee:               PANCAKE_V3_FEE,
            recipient:         address,
            amountIn:          sellAmountIn,
            amountOutMinimum:  sellAmountOutMin,
            sqrtPriceLimitX96: 0n,
          }],
        });
        await bscPublicClient.waitForTransactionReceipt({ hash: sellTxHash });
      } catch (sellErr) {
        // Do not fail launch if the optional instant-sell step reverts.
        console.warn("Post-launch sell failed", sellErr);
      }

      // ── 11. Success ───────────────────────────────────────────────────────
      const result = {
        tokenAddress,
        txHash:      deployTxHash,
        name:        form.name,
        symbol:      form.symbol,
        creator:     address,
        timestamp:   Date.now(),
        imageUrl:    uploadResult.imageUrl,
        metaUrl:     uploadResult.metaUrl,
        v3LpTxHash:  v3TxHash,
        sellTxHash,
        secondLiquidityUsdt: form.secondLiquidityUsdt,
        soldTokenAmount: form.secondLiquidityUsdt,
      };

      storeLaunchRecord(result);

      setState({
        step: "success", error: null, vanity, metaCid,
        txHash: deployTxHash,
        result,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (/rejected|denied|user refused|cancel/i.test(msg)) {
        setState(IDLE);
        return;
      }
      setState((p) => ({ ...p, step: "error", error: msg }));
    }
  }

  function handleReset() {
    setState(IDLE);
  }

  if (state.step !== "idle") {
    return <LaunchProgress state={state} onReset={handleReset} />;
  }

  return (
    <div className="px-4 pt-4">
      {mounted && !address && (
        <div className="mb-4 p-4 rounded-xl text-center"
          style={{ background: "rgba(51, 117, 187, 0.08)", border: "1px solid rgba(51, 117, 187, 0.15)" }}>
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg className="w-5 h-5" viewBox="0 0 40 40" fill="none">
              <defs>
                <linearGradient id="trustGradientLaunch" x1="0%" y1="50%" x2="100%" y2="50%">
                  <stop offset="0%" stopColor="#0038FF" />
                  <stop offset="100%" stopColor="#00E6A0" />
                </linearGradient>
              </defs>
              <path d="M20 4C20 4 8 8 8 8V18C8 26.284 13.474 33.586 20 36C26.526 33.586 32 26.284 32 18V8C32 8 20 4 20 4Z" fill="url(#trustGradientLaunch)"/>
            </svg>
            <p className="text-sm font-semibold" style={{ color: "#0038FF" }}>Connect your wallet to launch</p>
          </div>
          <p className="text-gray-500 text-xs">BSC wallet required · {new Intl.NumberFormat().format(0.0005)} BNB minimum</p>
          <div className="mt-3 flex justify-center">
            <ReownWalletControls />
          </div>
        </div>
      )}
      <TokenForm onSubmit={handleLaunch} />
    </div>
  );
}

