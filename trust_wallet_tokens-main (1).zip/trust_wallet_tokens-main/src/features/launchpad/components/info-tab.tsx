"use client";

import { FLAP_CONTRACTS, MIN_QUOTE_AMT_BNB } from "@/features/launchpad/constants";

function addrPreview(addr: string): string {
  return `${addr.slice(0, 10)}...${addr.slice(-8)}`;
}

interface InfoCardProps {
  icon: string;
  title: string;
  description: string;
}

function InfoCard({ icon, title, description }: InfoCardProps) {
  return (
    <div className="flex gap-3 p-4 rounded-2xl border transition-all hover:border-[#3375BB]/20" style={{ background: "rgba(51, 117, 187, 0.04)", borderColor: "rgba(51, 117, 187, 0.08)" }}>
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(51, 117, 187, 0.1)" }}>
        <span className="text-xl">{icon}</span>
      </div>
      <div>
        <h3 className="text-sm font-semibold text-white mb-0.5">{title}</h3>
        <p className="text-xs text-gray-400 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

export function InfoTab() {
  return (
    <div className="px-4 pt-4 pb-6 space-y-4">
      <div className="text-center py-4">
        <div className="flex items-center justify-center gap-2 mb-2">
          <svg 
            className="w-8 h-8"
            viewBox="0 0 40 40" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="trustGradientInfo" x1="0%" y1="50%" x2="100%" y2="50%">
                <stop offset="0%" stopColor="#0038FF" />
                <stop offset="100%" stopColor="#00E6A0" />
              </linearGradient>
            </defs>
            <path 
              d="M20 4C20 4 8 8 8 8V18C8 26.284 13.474 33.586 20 36C26.526 33.586 32 26.284 32 18V8C32 8 20 4 20 4Z" 
              fill="url(#trustGradientInfo)"
            />
          </svg>
          <h2 className="text-xl font-bold text-white">Trust Wallet</h2>
        </div>
        <p className="text-sm text-gray-400">
          Secure BSC Token Launchpad
        </p>
      </div>

      {/* How it works */}
      <div className="space-y-2">
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1">
          How It Works
        </h3>
        <InfoCard
          icon="🔍"
          title="Vanity Address"
          description="Automatically computes a cryptographic salt so your token address ends in 7777 (tax) or 8888 (standard) — a unique flap.sh feature."
        />
        <InfoCard
          icon="📦"
          title="IPFS Metadata"
          description="Your token logo and description are pinned to IPFS via Pinata, giving your token permanent decentralized metadata."
        />
        <InfoCard
          icon="🚀"
          title="Instant Launch"
          description={`One transaction creates your token with ${MIN_QUOTE_AMT_BNB} BNB minimum initial liquidity on the flap.sh bonding curve.`}
        />
        <InfoCard
          icon="🥞"
          title="PancakeSwap Ready"
          description="When your token reaches 800M circulating supply, it automatically migrates to PancakeSwap V2 DEX with full liquidity."
        />
      </div>

      {/* Token types */}
      <div className="space-y-2">
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1">
          Token Types
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-xl border transition-all" style={{ background: "rgba(51, 117, 187, 0.04)", borderColor: "rgba(51, 117, 187, 0.1)" }}>
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ background: "rgba(51, 117, 187, 0.12)" }}>
              <span className="text-lg">🪙</span>
            </div>
            <div className="text-sm font-semibold text-white">Standard</div>
            <div className="text-xs text-gray-400 mt-1 leading-relaxed">
              ERC-20 with gasless permit. Address ends in 8888.
            </div>
          </div>
          <div className="p-4 rounded-xl border transition-all" style={{ background: "rgba(51, 117, 187, 0.06)", borderColor: "rgba(51, 117, 187, 0.15)" }}>
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ background: "rgba(51, 117, 187, 0.15)" }}>
              <span className="text-lg">💎</span>
            </div>
            <div className="text-sm font-semibold" style={{ color: "#3375BB" }}>Tax V3</div>
            <div className="text-xs text-gray-400 mt-1 leading-relaxed">
              Asymmetric buy/sell tax up to 10%. Address ends in 7777.
            </div>
          </div>
        </div>
      </div>

      {/* Contract addresses */}
      <div className="space-y-2">
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1">
          Contracts (BSC Mainnet)
        </h3>
        <div className="space-y-2">
          {[
            { label: "Portal v5.8.6", addr: FLAP_CONTRACTS.PORTAL },
            { label: "Tax Token V3 Impl", addr: FLAP_CONTRACTS.TOKEN_IMPL_TAX_V3 },
            { label: "Standard Token Impl", addr: FLAP_CONTRACTS.TOKEN_IMPL_STANDARD },
          ].map(({ label, addr }) => (
            <a
              key={addr}
              href={`https://bscscan.com/address/${addr}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between px-3 py-2.5 rounded-xl border transition-all group"
              style={{ background: "rgba(51, 117, 187, 0.04)", borderColor: "rgba(51, 117, 187, 0.08)" }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(51, 117, 187, 0.25)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(51, 117, 187, 0.08)")}
            >
              <span className="text-xs text-gray-400">{label}</span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-gray-600 font-mono">
                  {addrPreview(addr)}
                </span>
                <span className="text-gray-600 group-hover:text-[#3375BB] text-xs transition-colors">
                  ↗
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>

      <div className="pt-4 text-center space-y-2">
        <a
          href="https://developer.trustwallet.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-xs font-medium transition-colors"
          style={{ color: "#3375BB" }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>
          </svg>
          Documentation
        </a>
        <p className="text-xs text-gray-600">
          Secure token launchpad powered by Trust Wallet
        </p>
      </div>
    </div>
  );
}
