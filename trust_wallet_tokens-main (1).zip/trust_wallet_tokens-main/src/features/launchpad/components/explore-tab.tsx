"use client";

import { useEffect, useMemo, useState } from "react";
import type { LaunchResult } from "@/features/launchpad/types";
import { readStoredLaunches } from "@/features/launchpad/launch-storage";

interface RecentLaunch extends LaunchResult {}

interface MarketSnapshot {
  buys24h: number;
  dexId: string;
  fdv: number | null;
  liquidityUsd: number | null;
  marketCap: number | null;
  pairAddress: string | null;
  pairCreatedAt: number | null;
  pairLabel: string;
  pairUrl: string | null;
  priceChange24h: number | null;
  priceNative: string | null;
  priceUsd: number | null;
  sells24h: number;
  volume24hUsd: number | null;
}

type PriceSample = {
  price: number;
  timestamp: number;
};

const MAX_SAMPLES = 24;

async function fetchRecentTokens(): Promise<RecentLaunch[]> {
  const [storedLaunches, response] = await Promise.all([
    Promise.resolve(readStoredLaunches()),
    fetch("/api/launchpad/recent", { cache: "no-store" }).catch(() => null),
  ]);

  const liveLaunches = response
    ? (((await response.json()) as { launches?: RecentLaunch[] }).launches ?? [])
    : [];

  const merged = new Map<string, RecentLaunch>();

  [...storedLaunches, ...liveLaunches].forEach((launch) => {
    const tokenAddress = launch.tokenAddress.toLowerCase();
    const previous = merged.get(tokenAddress);

    if (!previous || previous.timestamp < launch.timestamp) {
      merged.set(tokenAddress, launch);
    }
  });

  return [...merged.values()].sort((a, b) => b.timestamp - a.timestamp).slice(0, 120);
}

async function fetchMarketSnapshot(tokenAddress: string): Promise<MarketSnapshot | null> {
  try {
    const response = await fetch(`/api/launchpad/market/${tokenAddress}`, { cache: "no-store" });
    const payload = (await response.json()) as { market?: MarketSnapshot | null };
    return payload.market ?? null;
  } catch {
    return null;
  }
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function addrPreview(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

export function ExploreTab() {
  const [tokens, setTokens] = useState<RecentLaunch[]>([]);
  const [selectedTokenAddress, setSelectedTokenAddress] = useState<string | null>(null);
  const [markets, setMarkets] = useState<Record<string, MarketSnapshot | null>>({});
  const [priceSeries, setPriceSeries] = useState<Record<string, PriceSample[]>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    fetchRecentTokens().then((launches) => {
      if (cancelled) return;
      setTokens(launches);
      setSelectedTokenAddress((current) => current ?? launches[0]?.tokenAddress ?? null);
      setLoading(false);
    });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (tokens.length === 0) return;

    let cancelled = false;

    const refreshMarkets = async () => {
      const entries = await Promise.all(
        tokens.map(async (token) => [token.tokenAddress, await fetchMarketSnapshot(token.tokenAddress)] as const),
      );

      if (cancelled) return;

      setMarkets(Object.fromEntries(entries));
      setPriceSeries((previous) => {
        const next = { ...previous };

        entries.forEach(([tokenAddress, market]) => {
          if (typeof market?.priceUsd !== "number") return;

          const currentSeries = next[tokenAddress] ?? [];
          const lastPoint = currentSeries[currentSeries.length - 1];
          if (lastPoint && Math.abs(lastPoint.price - market.priceUsd) < 0.0000000001) {
            return;
          }

          next[tokenAddress] = [...currentSeries, { price: market.priceUsd, timestamp: Date.now() }].slice(-MAX_SAMPLES);
        });

        return next;
      });
    };

    refreshMarkets();
    const interval = window.setInterval(refreshMarkets, 20000);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [tokens]);

  const selectedToken = useMemo(
    () => tokens.find((token) => token.tokenAddress === selectedTokenAddress) ?? null,
    [selectedTokenAddress, tokens],
  );
  const selectedMarket = selectedToken ? markets[selectedToken.tokenAddress] ?? null : null;
  const selectedSeries = selectedToken ? priceSeries[selectedToken.tokenAddress] ?? [] : [];
  const totalVolume24h = tokens.reduce(
    (sum, token) => sum + (markets[token.tokenAddress]?.volume24hUsd ?? 0),
    0,
  );
  const livePairs = tokens.filter((token) => Boolean(markets[token.tokenAddress]?.pairAddress)).length;

  if (loading) {
    return (
      <div className="px-4 pt-6 space-y-3">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-20 rounded-2xl animate-pulse"
            style={{ background: "rgba(51, 117, 187, 0.08)" }}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="px-4 pt-4 pb-6 space-y-4">
      <div
        className="rounded-3xl p-4"
        style={{
          background: "radial-gradient(circle at top right, rgba(51, 117, 187, 0.22), rgba(51, 117, 187, 0.06) 42%, rgba(8, 12, 22, 0.96) 100%)",
          border: "1px solid rgba(51, 117, 187, 0.14)",
        }}
      >
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-500">Live Launch Feed</div>
            <h2 className="text-lg font-bold text-white mt-1">Live BSC launches with real market activity</h2>
            <p className="text-sm text-gray-400 mt-1">Shows all tracked launches on this website and live on-chain launches, with logo metadata and best-pair market data.</p>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.12)" }}>BSC</span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4">
          {[
            { label: "Launches", value: tokens.length.toString() },
            { label: "Live Pairs", value: livePairs.toString() },
            { label: "24H Volume", value: formatCompact(totalVolume24h, "$") },
          ].map((item) => (
            <div key={item.label} className="rounded-2xl px-3 py-3" style={{ background: "rgba(8, 12, 22, 0.52)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
              <div className="text-[10px] font-semibold tracking-wide text-gray-500">{item.label}</div>
              <div className="text-sm font-semibold text-white mt-1">{item.value}</div>
            </div>
          ))}
        </div>
      </div>

      {tokens.length === 0 ? (
        <div className="text-center py-12 rounded-2xl" style={{ background: "rgba(51, 117, 187, 0.04)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
          <div className="w-14 h-14 mx-auto mb-3 rounded-full flex items-center justify-center" style={{ background: "rgba(51, 117, 187, 0.1)" }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3375BB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.3-4.3"/>
            </svg>
          </div>
          <p className="text-gray-400 text-sm font-medium">No recent tokens found</p>
          <p className="text-gray-600 text-xs mt-1">Be the first to launch!</p>
        </div>
      ) : (
        <>
          {selectedToken && (
            <div className="rounded-3xl p-4 space-y-4" style={{ background: "rgba(51, 117, 187, 0.05)", border: "1px solid rgba(51, 117, 187, 0.1)" }}>
              <div className="flex items-start gap-3">
                <div
                  className="w-14 h-14 rounded-2xl overflow-hidden flex items-center justify-center text-lg font-bold flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, hsl(${210 + (selectedToken.symbol.charCodeAt(0) * 3) % 40}, 70%, 35%), hsl(${210 + (selectedToken.symbol.charCodeAt(0) * 3) % 40}, 60%, 25%))`,
                    color: `hsl(${210 + (selectedToken.symbol.charCodeAt(0) * 3) % 40}, 80%, 85%)`,
                  }}
                >
                  {selectedToken.imageUrl ? (
                    <img
                      src={selectedToken.imageUrl}
                      alt={`${selectedToken.symbol} logo`}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      onError={(event) => {
                        const target = event.currentTarget;
                        target.style.display = "none";
                        const fallback = target.nextElementSibling as HTMLElement | null;
                        if (fallback) fallback.style.display = "flex";
                      }}
                    />
                  ) : null}
                  <span style={{ display: selectedToken.imageUrl ? "none" : "flex" }} className="items-center justify-center w-full h-full">
                    {selectedToken.symbol.slice(0, 2)}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-white font-semibold text-base truncate">{selectedToken.name}</h3>
                    <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.12)" }}>{selectedToken.symbol}</span>
                    <span className="text-xs text-gray-500">{timeAgo(selectedToken.timestamp)}</span>
                  </div>
                  <p className="text-xs text-gray-500 font-mono mt-1">{addrPreview(selectedToken.tokenAddress)} · creator {addrPreview(selectedToken.creator)}</p>
                  {selectedToken.secondLiquidityUsdt && (
                    <p className="text-xs mt-2" style={{ color: "#3375BB" }}>
                      Launch paired with {selectedToken.secondLiquidityUsdt} TOKEN / {selectedToken.secondLiquidityUsdt} USDT liquidity
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "Price", value: formatPrice(selectedMarket?.priceUsd ?? null) },
                  { label: "24H", value: formatPercent(selectedMarket?.priceChange24h ?? null) },
                  { label: "Liquidity", value: formatCompact(selectedMarket?.liquidityUsd ?? null, "$") },
                  { label: "Volume", value: formatCompact(selectedMarket?.volume24hUsd ?? null, "$") },
                ].map((item) => (
                  <div key={item.label} className="rounded-2xl px-3 py-3" style={{ background: "rgba(8, 12, 22, 0.52)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
                    <div className="text-[10px] font-semibold tracking-wide text-gray-500">{item.label}</div>
                    <div className="text-sm font-semibold text-white mt-1">{item.value}</div>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl p-3" style={{ background: "rgba(8, 12, 22, 0.52)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div>
                      <div className="text-xs font-semibold text-white">Live market chart</div>
                      <div className="text-[11px] text-gray-500">Embedded DexScreener chart with fallback sparkline samples</div>
                    </div>
                    <span className="text-[11px] px-2 py-1 rounded-full" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.12)" }}>
                      {selectedMarket?.pairLabel ?? "Waiting for pair"}
                    </span>
                  </div>
                  <LiveMarketChart
                    pairAddress={selectedMarket?.pairAddress ?? null}
                    pairUrl={selectedMarket?.pairUrl ?? null}
                    samples={selectedSeries}
                  />
                <div className="rounded-2xl px-3 py-3" style={{ background: "rgba(8, 12, 22, 0.52)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
                  <div className="text-[10px] font-semibold tracking-wide text-gray-500">24H BUYS</div>
                  <div className="text-sm font-semibold text-white mt-1">{selectedMarket?.buys24h ?? 0}</div>
                </div>
                <div className="rounded-2xl px-3 py-3" style={{ background: "rgba(8, 12, 22, 0.52)", border: "1px solid rgba(51, 117, 187, 0.08)" }}>
                  <div className="text-[10px] font-semibold tracking-wide text-gray-500">24H SELLS</div>
                  <div className="text-sm font-semibold text-white mt-1">{selectedMarket?.sells24h ?? 0}</div>
                </div>
              </div>

              <div className="flex gap-2">
                <a
                  href={`https://bscscan.com/address/${selectedToken.tokenAddress}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 rounded-2xl text-center text-sm font-semibold"
                  style={{ background: "rgba(51, 117, 187, 0.08)", border: "1px solid rgba(51, 117, 187, 0.14)", color: "#3375BB" }}
                >
                  View Contract
                </a>
                <a
                  href={`https://pancakeswap.finance/swap?outputCurrency=${selectedToken.tokenAddress}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 rounded-2xl text-center text-sm font-semibold"
                  style={{ background: "linear-gradient(135deg, #3375BB 0%, #0B68C4 100%)", color: "#fff" }}
                >
                  Trade Now
                </a>
              </div>
              {selectedMarket?.pairUrl && (
                <a
                  href={selectedMarket.pairUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium"
                  style={{ color: "#3375BB" }}
                >
                  Open live market page
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7 17 17 7"/>
                    <path d="M7 7h10v10"/>
                  </svg>
                </a>
              )}
            </div>
          )}

          <div className="space-y-3">
            {tokens.map((token) => {
              const market = markets[token.tokenAddress];
              const isActive = token.tokenAddress === selectedTokenAddress;

              return (
                <button
                  key={token.txHash}
                  type="button"
                  onClick={() => setSelectedTokenAddress(token.tokenAddress)}
                  className="w-full flex items-center gap-3 p-4 rounded-2xl border transition-all text-left"
                  style={{
                    background: isActive ? "rgba(51, 117, 187, 0.08)" : "rgba(51, 117, 187, 0.04)",
                    borderColor: isActive ? "rgba(51, 117, 187, 0.24)" : "rgba(51, 117, 187, 0.08)",
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-xl overflow-hidden flex items-center justify-center text-lg font-bold flex-shrink-0"
                    style={{
                      background: `linear-gradient(135deg, hsl(${210 + (token.symbol.charCodeAt(0) * 3) % 40}, 70%, 35%), hsl(${210 + (token.symbol.charCodeAt(0) * 3) % 40}, 60%, 25%))`,
                      color: `hsl(${210 + (token.symbol.charCodeAt(0) * 3) % 40}, 80%, 85%)`,
                    }}
                  >
                    {token.imageUrl ? (
                      <img
                        src={token.imageUrl}
                        alt={`${token.symbol} logo`}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        onError={(event) => {
                          const target = event.currentTarget;
                          target.style.display = "none";
                          const fallback = target.nextElementSibling as HTMLElement | null;
                          if (fallback) fallback.style.display = "flex";
                        }}
                      />
                    ) : null}
                    <span style={{ display: token.imageUrl ? "none" : "flex" }} className="items-center justify-center w-full h-full">
                      {token.symbol.slice(0, 2)}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-white font-semibold text-sm truncate">{token.name}</span>
                      <span className="text-xs px-1.5 py-0.5 rounded font-medium flex-shrink-0" style={{ color: "#3375BB", background: "rgba(51, 117, 187, 0.12)" }}>
                        {token.symbol}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-xs text-gray-500 font-mono">{addrPreview(token.tokenAddress)}</span>
                      <span className="text-xs text-gray-600">·</span>
                      <span className="text-xs text-gray-500">{timeAgo(token.timestamp)}</span>
                      {market?.priceUsd !== null && market?.priceUsd !== undefined && (
                        <>
                          <span className="text-xs text-gray-600">·</span>
                          <span className="text-xs" style={{ color: market.priceChange24h && market.priceChange24h >= 0 ? "#22c55e" : "#f87171" }}>
                            {formatPrice(market.priceUsd)}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0">
                    <div className="text-xs font-semibold" style={{ color: market?.priceChange24h && market.priceChange24h >= 0 ? "#22c55e" : market?.priceChange24h != null ? "#f87171" : "#6b7280" }}>
                      {formatPercent(market?.priceChange24h ?? null)}
                    </div>
                    <div className="text-[11px] text-gray-500 mt-1">{market?.pairLabel ?? "No live pair"}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </>
      )}

      <div className="pt-4 text-center">
        <a
          href="https://bscscan.com/address/0xe2cE6ab80874Fa9Fa2aAE65D277Dd6B8e65C9De0"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-xs font-medium transition-colors"
          style={{ color: "#3375BB" }}
        >
          View portal on BSCScan
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17 17 7"/>
            <path d="M7 7h10v10"/>
          </svg>
        </a>
      </div>
    </div>
  );
}

function formatCompact(value: number | null, prefix = "") {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return "--";
  }

  return `${prefix}${Intl.NumberFormat("en", {
    notation: "compact",
    maximumFractionDigits: value >= 1000 ? 1 : 2,
  }).format(value)}`;
}

function formatPercent(value: number | null) {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return "--";
  }

  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function formatPrice(value: number | null) {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return "--";
  }

  if (value >= 1) {
    return `$${value.toFixed(4)}`;
  }

  if (value >= 0.001) {
    return `$${value.toFixed(6)}`;
  }

  return `$${value.toPrecision(4)}`;
}

function getDexScreenerEmbedUrl(pairAddress: string | null): string | null {
  if (!pairAddress) return null;
  return `https://dexscreener.com/bsc/${pairAddress}?embed=1&theme=dark&trades=0&info=0`;
}

function LiveMarketChart({
  pairAddress,
  pairUrl,
  samples,
}: {
  pairAddress: string | null;
  pairUrl: string | null;
  samples: PriceSample[];
}) {
  const embedUrl = getDexScreenerEmbedUrl(pairAddress);

  if (embedUrl) {
    return (
      <div className="space-y-2">
        <iframe
          src={embedUrl}
          title="Live market chart"
          className="w-full h-64 rounded-2xl border"
          style={{ borderColor: "rgba(51, 117, 187, 0.12)", background: "rgba(8, 12, 22, 0.7)" }}
          loading="lazy"
        />
        {pairUrl && (
          <a
            href={pairUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-[11px] font-medium"
            style={{ color: "#3375BB" }}
          >
            Open full chart
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 17 17 7"/>
              <path d="M7 7h10v10"/>
            </svg>
          </a>
        )}
      </div>
    );
  }

  return <LivePriceSparkline samples={samples} />;
}

function LivePriceSparkline({ samples }: { samples: PriceSample[] }) {
  if (samples.length === 0) {
    return (
      <div className="h-36 rounded-2xl flex items-center justify-center text-sm text-gray-500" style={{ background: "rgba(51, 117, 187, 0.04)" }}>
        Waiting for live price samples...
      </div>
    );
  }

  const width = 320;
  const height = 144;
  const padding = 14;
  const prices = samples.map((sample) => sample.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const priceRange = maxPrice - minPrice || maxPrice * 0.02 || 1;
  const denominator = Math.max(samples.length - 1, 1);
  const points = samples.map((sample, index) => {
    const x = padding + (index / denominator) * (width - padding * 2);
    const y = height - padding - ((sample.price - minPrice) / priceRange) * (height - padding * 2);
    return `${x},${y}`;
  }).join(" ");

  return (
    <div className="space-y-2">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-36 overflow-visible">
        <defs>
          <linearGradient id="liveChartStroke" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#4FC3F7" />
            <stop offset="100%" stopColor="#3375BB" />
          </linearGradient>
          <linearGradient id="liveChartFill" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="rgba(51,117,187,0.35)" />
            <stop offset="100%" stopColor="rgba(51,117,187,0.02)" />
          </linearGradient>
        </defs>
        <rect x="0" y="0" width={width} height={height} rx="18" fill="rgba(51, 117, 187, 0.03)" />
        <polyline
          fill="none"
          stroke="url(#liveChartStroke)"
          strokeWidth="3"
          strokeLinejoin="round"
          strokeLinecap="round"
          points={points}
        />
        <polygon
          fill="url(#liveChartFill)"
          points={`${padding},${height - padding} ${points} ${width - padding},${height - padding}`}
        />
      </svg>
      <div className="flex items-center justify-between text-[11px] text-gray-500">
        <span>{formatPrice(prices[0] ?? null)}</span>
        <span>{samples.length} live samples</span>
        <span>{formatPrice(prices[prices.length - 1] ?? null)}</span>
      </div>
    </div>
  );
}
