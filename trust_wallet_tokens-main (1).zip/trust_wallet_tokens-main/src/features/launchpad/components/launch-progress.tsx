"use client";

import type { LaunchState } from "@/features/launchpad/types";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";

interface LaunchProgressProps {
  state: LaunchState;
  onReset: () => void;
}

const STEPS = [
  { key: "computing-salt",   label: "Computing vanity address",          icon: "🔍" },
  { key: "uploading-meta",   label: "Uploading metadata to IPFS",        icon: "📦" },
  { key: "awaiting-tx",      label: "Awaiting wallet signature",         icon: "✍️" },
  { key: "confirming",       label: "Confirming token deploy on BSC",    icon: "⛓️" },
  { key: "approving-token",  label: "Approving token allowance",         icon: "✍️" },
  { key: "approving-usdt",   label: "Approving USDT allowance",          icon: "✍️" },
  { key: "creating-v3-pool", label: "Creating PancakeSwap V3 pool (0.01%)", icon: "🏊" },
  { key: "adding-v3-lp",     label: "Confirming custom 1:1 TOKEN/USDT liquidity", icon: "⛓️" },
  { key: "selling-token",    label: "Selling full second-liquidity token amount to USDT",  icon: "💱" },
];

export function LaunchProgress({ state, onReset }: LaunchProgressProps) {
  const stepIndex = STEPS.findIndex((s) => s.key === state.step);

  if (state.step === "success" && state.result) {
    return (
      <div className="flex flex-col items-center gap-6 py-8 px-4 text-center">
        <div className="w-20 h-20 rounded-full flex items-center justify-center" style={{ background: "rgba(51, 117, 187, 0.15)" }}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#3375BB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Token Launched!</h2>
          <p className="text-gray-400 text-sm">Your token is live on BSC</p>
        </div>

        <div className="w-full space-y-3">
          <div className="p-4 rounded-xl" style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.15)" }}>
            <p className="text-xs text-gray-500 mb-1">Token Name</p>
            <p className="text-white font-semibold">
              {state.result.name} ({state.result.symbol})
            </p>
          </div>
          <div className="p-4 rounded-xl" style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.15)" }}>
            <p className="text-xs text-gray-500 mb-1">Token Address</p>
            <p className="font-mono text-xs break-all" style={{ color: "#3375BB" }}>
              {state.result.tokenAddress}
            </p>
          </div>
          {state.result.secondLiquidityUsdt && (
            <div className="p-4 rounded-xl" style={{ background: "rgba(51, 117, 187, 0.06)", border: "1px solid rgba(51, 117, 187, 0.15)" }}>
              <p className="text-xs text-gray-500 mb-1">USDT Pair Liquidity</p>
              <p className="text-white font-semibold">
                {state.result.secondLiquidityUsdt} TOKEN + {state.result.secondLiquidityUsdt} USDT
              </p>
            </div>
          )}
          {state.result.soldTokenAmount && (
            <div className="p-4 rounded-xl" style={{ background: "rgba(245, 158, 11, 0.08)", border: "1px solid rgba(245, 158, 11, 0.2)" }}>
              <p className="text-xs text-gray-500 mb-1">Final Sell Amount</p>
              <p className="text-white font-semibold">
                Sold {state.result.soldTokenAmount} TOKEN back to USDT
              </p>
            </div>
          )}
          {state.txHash && (
            <a
              href={`https://bscscan.com/tx/${state.txHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-medium transition-colors"
              style={{ background: "rgba(51, 117, 187, 0.08)", border: "1px solid rgba(51, 117, 187, 0.12)", color: "#3375BB" }}
            >
              <span>View deploy tx on BSCScan</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M7 17 17 7"/>
                <path d="M7 7h10v10"/>
              </svg>
            </a>
          )}
          {state.result?.v3LpTxHash && (
            <a
              href={`https://bscscan.com/tx/${state.result.v3LpTxHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-medium transition-colors"
              style={{ background: "rgba(34, 197, 94, 0.06)", border: "1px solid rgba(34, 197, 94, 0.2)", color: "#22c55e" }}
            >
              <span>View PancakeSwap V3 LP tx</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M7 17 17 7"/>
                <path d="M7 7h10v10"/>
              </svg>
            </a>
          )}
          {state.result?.sellTxHash && (
            <a
              href={`https://bscscan.com/tx/${state.result.sellTxHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-medium transition-colors"
              style={{ background: "rgba(245, 158, 11, 0.08)", border: "1px solid rgba(245, 158, 11, 0.25)", color: "#f59e0b" }}
            >
              <span>View full liquidity sell tx (USDT)</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M7 17 17 7"/>
                <path d="M7 7h10v10"/>
              </svg>
            </a>
          )}
          <a
            href={`https://pancakeswap.finance/swap?outputCurrency=${state.result.tokenAddress}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-sm font-semibold transition-all"
            style={{ background: "linear-gradient(135deg, #3375BB 0%, #0B68C4 100%)", color: "#ffffff" }}
          >
            <span>Trade on PancakeSwap</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="m16 12-4 4-4-4"/>
              <path d="m16 8-4 4-4-4"/>
            </svg>
          </a>
        </div>

        <ShareButton
          text={`Just launched ${state.result.name} (${state.result.symbol}) on BSC via Trust Wallet Launchpad!`}
          queryParams={{
            name: state.result.name,
            symbol: state.result.symbol,
          }}
          variant="default"
          size="lg"
        >
          Share on Farcaster
        </ShareButton>

        <button
          onClick={onReset}
          className="text-sm font-medium transition-colors"
          style={{ color: "#3375BB" }}
        >
          Launch another token
        </button>
      </div>
    );
  }

  if (state.step === "error") {
    return (
      <div className="flex flex-col items-center gap-6 py-8 px-4 text-center">
        <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "rgba(239, 68, 68, 0.15)" }}>
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <path d="m15 9-6 6"/>
            <path d="m9 9 6 6"/>
          </svg>
        </div>
        <div>
          <h2 className="text-xl font-bold text-white mb-2">Launch Failed</h2>
          <p className="text-red-400 text-sm max-w-xs">{state.error ?? "An unknown error occurred"}</p>
        </div>
        <button
          onClick={onReset}
          className="px-6 py-3 rounded-xl font-semibold text-sm transition-all"
          style={{
            background: "linear-gradient(135deg, #3375BB 0%, #0B68C4 100%)",
            color: "#ffffff",
          }}
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-6 py-8 px-4">
      {/* Spinner */}
      <div className="relative w-20 h-20">
        <div className="absolute inset-0 rounded-full" style={{ border: "4px solid rgba(51, 117, 187, 0.15)" }} />
        <div
          className="absolute inset-0 rounded-full border-4 border-transparent"
          style={{ borderTopColor: "#3375BB", animation: "spin 1s linear infinite" }}
        />
        <div className="absolute inset-0 flex items-center justify-center text-2xl">
          {STEPS[stepIndex]?.icon ?? "⚙️"}
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-lg font-bold text-white mb-1">Launching Token</h2>
        <p className="text-gray-400 text-sm">{STEPS[stepIndex]?.label ?? "Processing..."}</p>
        {state.step === "computing-salt" && state.vanity && (
          <p className="text-xs mt-1" style={{ color: "#3375BB" }}>
            {state.vanity.iterations.toLocaleString()} iterations...
          </p>
        )}
      </div>

      {/* Progress steps */}
      <div className="w-full space-y-2">
        {STEPS.map((step, i) => {
          const isDone = i < stepIndex;
          const isActive = i === stepIndex;
          return (
            <div
              key={step.key}
              className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all"
              style={{
                background: isActive ? "rgba(51, 117, 187, 0.1)" : isDone ? "rgba(34, 197, 94, 0.06)" : "rgba(51, 117, 187, 0.04)",
                border: isActive ? "1px solid rgba(51, 117, 187, 0.3)" : isDone ? "1px solid rgba(34, 197, 94, 0.2)" : "1px solid rgba(51, 117, 187, 0.08)"
              }}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: isActive ? "rgba(51, 117, 187, 0.15)" : isDone ? "rgba(34, 197, 94, 0.12)" : "rgba(51, 117, 187, 0.08)" }}>
                <span className="text-sm">
                  {isDone ? "✓" : isActive ? step.icon : "○"}
                </span>
              </div>
              <span
                className="text-sm font-medium"
                style={{ color: isActive ? "#3375BB" : isDone ? "#22c55e" : "#6b7280" }}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
