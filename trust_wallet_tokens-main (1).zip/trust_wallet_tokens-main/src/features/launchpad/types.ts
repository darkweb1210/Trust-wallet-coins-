export type TokenVersion = "TOKEN_V2_PERMIT" | "TOKEN_TAXED_V3";

export interface TokenFormData {
  name:            string;
  symbol:          string;
  description:     string;
  website:         string;
  twitter:         string;
  telegram:        string;
  imageFile:       File | null;
  imagePreviewUrl: string | null;
  // Token type
  tokenVersion:   TokenVersion;
  // Tax config (only used when tokenVersion === "TOKEN_TAXED_V3")
  buyTaxRate:     number;   // basis points, 0–1000
  sellTaxRate:    number;   // basis points, 0–1000
  taxDuration:    number;   // days
  // Initial liquidity
  quoteAmt:       string;   // BNB amount as string e.g. "0.0005"
  // Secondary PancakeSwap V3 liquidity, paired against USDT at 1:1
  secondLiquidityUsdt: string;
}

export interface LaunchResult {
  tokenAddress: string;
  txHash:       string;
  name:         string;
  symbol:       string;
  creator:      string;
  timestamp:    number;
  imageUrl?:    string;
  metaUrl?:     string;
  v3LpTxHash?:  string;
  sellTxHash?:  string;
  secondLiquidityUsdt?: string;
  soldTokenAmount?: string;
}

export interface VanityResult {
  salt:         string;  // bytes32 hex
  tokenAddress: string;  // predicted CREATE2 address
  iterations:   number;
}

export interface UploadMetaResult {
  cid:      string;   // IPFS CID
  imageUrl: string;
  metaUrl:  string;
}

export type LaunchStep =
  | "idle"
  | "computing-salt"
  | "uploading-meta"
  | "awaiting-tx"
  | "confirming"
  | "approving-token"
  | "approving-usdt"
  | "creating-v3-pool"
  | "adding-v3-lp"
  | "selling-token"
  | "success"
  | "error";

export interface LaunchState {
  step:    LaunchStep;
  error:   string | null;
  result:  LaunchResult | null;
  vanity:  VanityResult | null;
  metaCid: string | null;
  txHash:  string | null;
}
