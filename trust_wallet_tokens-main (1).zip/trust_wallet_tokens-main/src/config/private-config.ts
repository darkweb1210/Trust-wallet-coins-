import "server-only";
import { z } from "zod";

const privateConfigSchema = z.object({
  neynarApiKey: z.string(),
  coingeckoApiKey: z.string(),
});

const rawPrivateConfig = {
  neynarApiKey: process.env.NEYNAR_API_KEY || "",
  coingeckoApiKey:
    // demo coingecko key, not sensitive
    process.env.COINGECKO_API_KEY || "CG-UviYfmkExfr86X5JFTZfaVbb",
};

const parsedPrivateConfig = privateConfigSchema.safeParse(rawPrivateConfig);

if (!parsedPrivateConfig.success) {
  console.warn("Private config validation failed:", parsedPrivateConfig.error);
}

export const privateConfig = rawPrivateConfig;
