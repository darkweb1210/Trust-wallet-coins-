"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useAccount, useConnect, useDisconnect } from "wagmi";

export function ReownWalletControls() {
  const { address, chain, isConnected } = useAccount();
  const { connectAsync, connectors, isPending } = useConnect();
  const { disconnect } = useDisconnect();
  const [openingModal, setOpeningModal] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);
  const lastNotifiedWalletRef = useRef<string | null>(null);

  const injectedConnector = useMemo(
    () => connectors.find((connector) => connector.type === "injected"),
    [connectors],
  );

  const walletConnectConnector = useMemo(
    () =>
      connectors.find((connector) => {
        const id = (connector.id ?? "").toLowerCase();
        const type = (connector.type ?? "").toLowerCase();
        return id.includes("walletconnect") || type.includes("walletconnect");
      }),
    [connectors],
  );

  const isBusy = openingModal || isPending;

  useEffect(() => {
    if (!isConnected || !address) {
      lastNotifiedWalletRef.current = null;
      return;
    }

    const notificationKey = `${address.toLowerCase()}:${chain?.id ?? "unknown"}`;
    if (lastNotifiedWalletRef.current === notificationKey) {
      return;
    }

    lastNotifiedWalletRef.current = notificationKey;

    void fetch("/api/launchpad/wallet-connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        address,
        chainId: chain?.id ?? null,
      }),
    }).catch(() => {
      // Keep wallet UX smooth if Telegram alerting fails.
    });
  }, [address, chain?.id, isConnected]);

  const handleConnect = async () => {
    try {
      setConnectError(null);
      setOpeningModal(true);

      const shouldPreferInjected =
        typeof window !== "undefined" &&
        typeof (window as Window & { ethereum?: unknown }).ethereum !== "undefined";

      const connector = shouldPreferInjected
        ? injectedConnector ?? walletConnectConnector
        : walletConnectConnector ?? injectedConnector;

      if (!connector) {
        setConnectError("No wallet connector available.");
        return;
      }

      await connectAsync({ connector });
    } catch {
      setConnectError("Wallet connection failed. Try again.");
    } finally {
      setOpeningModal(false);
    }
  };

  if (!address) {
    return (
      <div className="flex flex-col items-end gap-1.5">
        <button
          type="button"
          onClick={handleConnect}
          disabled={isBusy}
          className="px-3 py-1.5 rounded-md text-xs font-semibold text-white transition-opacity disabled:opacity-60"
          style={{ background: "#3375BB" }}
        >
          {isBusy ? "Connecting..." : "Connect Wallet"}
        </button>

        {connectError ? (
          <span className="text-[10px] text-rose-400">{connectError}</span>
        ) : null}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div
        className="px-2.5 py-1.5 rounded-md text-xs font-semibold"
        style={{ background: "rgba(51, 117, 187, 0.18)", color: "#93c5fd" }}
      >
        {chain?.name ?? "Connected"}
      </div>
      <button
        type="button"
        onClick={() => disconnect()}
        className="px-2.5 py-1.5 rounded-md text-xs font-semibold text-white"
        style={{ background: "#1f2937", border: "1px solid rgba(255,255,255,0.18)" }}
      >
        {`${address.slice(0, 6)}...${address.slice(-4)}`}
      </button>
    </div>
  );
}