import { Metadata } from "next";
import { MiniAppEmbedNext } from "@farcaster/miniapp-sdk";
import { parsePageSearchParams } from "./helpers";

type FarcasterPageMetadataProps = {
  title: string;
  description: string;
  homeUrl: string;
  path: string;
  splashImageUrl: string;
  splashBackgroundColor: string;
  buttonTitle: string;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
};

export async function getFarcasterPageMetadata({
  title,
  description,
  homeUrl,
  path,
  splashImageUrl,
  splashBackgroundColor,
  buttonTitle,
  searchParams,
}: FarcasterPageMetadataProps): Promise<Metadata> {
  const params = await parsePageSearchParams(searchParams);
  const paramKeys = Object.keys(params);
  const isPersonalized = paramKeys.includes("personalize");
  const shareImageVersion =
    process.env.NEXT_PUBLIC_SHARE_IMAGE_VERSION ?? "trust-wallet-v2";

  const conditionalQueryString =
    isPersonalized && paramKeys.length > 0
      ? `?${new URLSearchParams(params).toString()}`
      : "";

  const shareImageParams = new URLSearchParams({ v: shareImageVersion });
  if (isPersonalized && paramKeys.length > 0) {
    for (const [key, value] of Object.entries(params)) {
      if (value != null) {
        shareImageParams.set(key, value);
      }
    }
  }
  const shareImageQueryString = `?${shareImageParams.toString()}`;

  // Remove leading slashes from path
  const cleanPath = path ? `/${path.replace(/^\/+/, "")}` : "";
  const pagePath = `${homeUrl}${cleanPath}${conditionalQueryString}`;

  const shareImageRoot = `${homeUrl}/api/share/image`;
  const ogImageUrlValue = `${shareImageRoot}/og${shareImageQueryString}`;
  const farcasterImageUrlValue =
    `${shareImageRoot}/farcaster${shareImageQueryString}`;

  const embed: MiniAppEmbedNext = {
    version: "next",
    imageUrl: farcasterImageUrlValue,
    button: {
      title: buttonTitle,
      action: {
        type: "launch_miniapp",
        name: title,
        url: pagePath,
        splashImageUrl,
        splashBackgroundColor,
      },
    },
  };

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: [{ url: ogImageUrlValue, width: 1200, height: 630 }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImageUrlValue],
    },
    other: {
      "fc:miniapp": JSON.stringify(embed),
    },
  };
}
